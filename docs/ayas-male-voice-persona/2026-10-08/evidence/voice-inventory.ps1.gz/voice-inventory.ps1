$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Speech
$taskSynth = [System.Speech.Synthesis.SpeechSynthesizer]::new()
try {
  $taskSynth.GetInstalledVoices() | ForEach-Object {
    [ordered]@{name=$_.VoiceInfo.Name;culture=$_.VoiceInfo.Culture.Name;gender=[string]$_.VoiceInfo.Gender;enabled=$_.Enabled}
  } | ConvertTo-Json -Depth 3
} finally { $taskSynth.Dispose() }
