const fs=require('node:fs'),path=require('node:path'),{spawn}=require('node:child_process'),assert=require('node:assert/strict');
const root=process.cwd(),start=performance.now(),child=spawn(path.join(root,'bin/piper/piper.exe'),['--model','tr_TR-dfki-medium.onnx','--espeak_data','espeak-ng-data','--output_raw'],{cwd:path.join(root,'bin/piper'),windowsHide:true,stdio:['pipe','ignore','pipe']});
let requested=null;child.stdin.on('error',()=>{});child.stdin.end(('Bu yalnızca izole iptal testidir. ').repeat(300)+'\n');
const limit=setTimeout(()=>{child.kill();throw Error('process cancellation timeout');},5000);
child.on('error',e=>{clearTimeout(limit);throw e});
setTimeout(()=>{requested=performance.now();assert.equal(child.kill(),true)},100);
child.on('close',(code,signal)=>{clearTimeout(limit);assert.ok(requested!==null);const r={status:'PASS',scope:'isolated Piper subprocess termination only; browser interruption is not tested',cancellationMs:performance.now()-requested,totalMs:performance.now()-start,exitCode:code,signal,liveVoiceChanged:false};fs.writeFileSync('.graphify/male-voice-persona/2026-10-08/CANCEL.json',JSON.stringify(r,null,2)+'\n');console.log(JSON.stringify(r));});
