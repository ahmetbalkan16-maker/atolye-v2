import hashlib,json,pathlib,wave
import numpy as np
root=pathlib.Path.cwd();file=root/'.graphify/male-voice-persona/2026-10-08/ayas-calm-male-evaluation-0.wav'
with wave.open(str(file),'rb') as r:
    sr=r.getframerate();channels=r.getnchannels();width=r.getsampwidth();raw=r.readframes(r.getnframes())
assert channels==1 and width==2
pcm=np.frombuffer(raw,dtype='<i2').astype(np.float64)/32768
f0=[];frames=0
for off in range(0,len(pcm)-2048,512):
    frame=pcm[off:off+2048];frames+=1
    if np.sqrt(np.mean(frame*frame))<.015:continue
    frame=frame-frame.mean();acf=np.correlate(frame,frame,mode='full')[2047:]
    lo,hi=int(sr/350),int(sr/70);lag=lo+np.argmax(acf[lo:hi+1])
    if acf[0]>0 and acf[lag]/acf[0]>=.7:f0.append(sr/lag)
r={'status':'REFERENCE_SIGNAL_MEASURED_ONLY','file':str(file.relative_to(root)),'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'sampleRate':sr,'channels':channels,'durationSeconds':len(pcm)/sr,'rms':float(np.sqrt(np.mean(pcm*pcm))),'peak':float(np.max(np.abs(pcm))),'nearFullScaleSamples':int(np.sum(np.abs(pcm)>=.999)),'clippedSamples':int(np.sum((pcm>=32767/32768)|(pcm<=-1))),'voicedPitchEstimateHzMedian':float(np.median(f0)) if f0 else None,'pitchFrames':len(f0),'analyzedFrames':frames,'pitchLimit':'autocorrelation proxy, susceptible to octave error; not a perceived bass or male-identity judgement','intelligibility':'NOT_MEASURED','ayasPronunciation':'OWNER_LISTENING_NOT_RUN','naturalness':'OWNER_LISTENING_NOT_RUN','historicalFirstPcmP95Ms':478.8534,'historicalLatencyScope':'previous local Piper subprocess 10 sentence corpus; cloud/network conditions are not equivalent','originalFileChanged':False}
(root/'.graphify/male-voice-persona-v2/REFERENCE_EVALUATION.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8');print(json.dumps(r,ensure_ascii=False))
