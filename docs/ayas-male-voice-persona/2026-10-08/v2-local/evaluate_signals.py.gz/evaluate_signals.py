"""Objective demo waveform proxies; no perceptual or gender acceptance claims."""
import hashlib
import json
import pathlib
import wave
import numpy as np

root = pathlib.Path(__file__).resolve().parent
output = root / "DEMO_SIGNALS.json"
assert not output.exists()
rows = []
for name in ("CALM", "PROFESSIONAL", "INTELLIGENT"):
    path = root / "audio-local" / f"AYAS_{name}_V2.wav"
    with wave.open(str(path), "rb") as reader:
        rate = reader.getframerate()
        assert reader.getnchannels() == 1 and reader.getsampwidth() == 2
        pcm16 = np.frombuffer(reader.readframes(reader.getnframes()), dtype="<i2")
    pcm = pcm16.astype(np.float64) / 32768
    f0 = []
    for offset in range(0, len(pcm) - 2048, 512):
        frame = pcm[offset:offset + 2048]
        if np.sqrt(np.mean(frame * frame)) < .015:
            continue
        frame = frame - frame.mean()
        acf = np.correlate(frame, frame, mode="full")[2047:]
        low, high = int(rate / 350), int(rate / 70)
        lag = low + np.argmax(acf[low:high + 1])
        if acf[0] > 0 and acf[lag] / acf[0] >= .7:
            f0.append(rate / lag)
    rows.append({"candidate": name, "file": path.relative_to(root).as_posix(),
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "sampleRate": rate,
        "durationSeconds": len(pcm) / rate, "pcmPeak": float(np.max(np.abs(pcm))),
        "pcmRms": float(np.sqrt(np.mean(pcm * pcm))),
        "clippedSamples": int(np.sum((pcm16 == 32767) | (pcm16 == -32768))),
        "voicedPitchProxyHzMedian": float(np.median(f0)) if f0 else None, "pitchFrameCount": len(f0),
        "limit": "Autocorrelation F0 proxy may have octave errors; not subjective depth, identity, male-gender or naturalness acceptance"})
output.write_text(json.dumps({"status": "DEMO_SIGNAL_PROXIES_ONLY", "rows": rows}, indent=2) + "\n", encoding="utf-8")
print(json.dumps(rows))
