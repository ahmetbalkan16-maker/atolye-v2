"""Bounded, offline-only evaluation of three released synthetic Pocket voices.

This is an isolated evidence recipe, not an AYAS provider or deployment adapter.
"""
import os
os.environ.update(HF_HUB_OFFLINE="1", HF_HUB_DISABLE_TELEMETRY="1", DO_NOT_TRACK="1",
                  OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", CUDA_VISIBLE_DEVICES="")
import ctypes
import hashlib
import json
import pathlib
import shutil
import tempfile
import time
import wave
from ctypes import wintypes

ROOT = pathlib.Path(__file__).resolve().parent
PLAN = json.loads((ROOT / "LOCAL_PLAN.json").read_text("utf-8-sig"))
CORPUS = json.loads((ROOT / "TEST_CORPUS.json").read_text("utf-8-sig"))["texts"]
assert len(CORPUS) == 16 and len(PLAN["candidates"]) == 3
assert PLAN["device"] == "cpu" and PLAN["maximumSyntheses"] == 54
RESULT = ROOT / "LOCAL_RESULTS.json"
assert not RESULT.exists(), "Existing evidence must be preserved before any rerun"

class MemoryCounters(ctypes.Structure):
    _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD)] + [
        (name, ctypes.c_size_t) for name in (
            "PeakWorkingSetSize", "WorkingSetSize", "QuotaPeakPagedPoolUsage",
            "QuotaPagedPoolUsage", "QuotaPeakNonPagedPoolUsage", "QuotaNonPagedPoolUsage",
            "PagefileUsage", "PeakPagefileUsage", "PrivateUsage")]

def memory():
    counters = MemoryCounters()
    counters.cb = ctypes.sizeof(counters)
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    psapi = ctypes.WinDLL("psapi", use_last_error=True)
    psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD]
    if not psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(counters), counters.cb):
        raise ctypes.WinError(ctypes.get_last_error())
    return {"workingSetBytes": counters.WorkingSetSize, "peakWorkingSetBytes": counters.PeakWorkingSetSize,
            "privateBytes": counters.PrivateUsage}

started = time.perf_counter()
staged = None
report = {"status": "RUNNING", "model": PLAN["model"], "revision": PLAN["revision"],
          "scope": "offline CPU subprocess; synthetic bundled voices only; no live playback",
          "threads": 1, "seed": PLAN["seed"], "rows": [], "cancellation": [],
          "ownerListening": "NOT_RUN", "naturalness": "NOT_MEASURED",
          "ayasPhoneticAcceptance": "OWNER_LISTENING_REQUIRED", "deployment": "NOT_RUN"}

def checkpoint():
    RESULT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def budget():
    if time.perf_counter() - started > PLAN["maximumWallSeconds"]:
        raise TimeoutError("Fixed evaluation wall budget exhausted")

try:
    import numpy as np
    import torch
    import importlib.metadata
    from pocket_tts_turkish import TurkishTTS, save_wav
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    report["versions"] = {k: importlib.metadata.version(k) for k in (
        "torch", "numpy", "pocket-tts", "pocket-tts-turkish", "safetensors", "sentencepiece")}
    start = time.perf_counter()
    # SentencePiece's Windows file loader fails on the existing Unicode workspace
    # path. Stage only the seven verified data files under an ASCII temp path;
    # upstream code, installed AYAS and the original model files stay unchanged.
    staged = pathlib.Path(tempfile.mkdtemp(prefix="ayas-tts-v2-"))
    assert staged.resolve().is_relative_to(pathlib.Path(tempfile.gettempdir()).resolve())
    assert staged.name.startswith("ayas-tts-v2-") and staged.as_posix().isascii()
    manifest = json.loads((ROOT / "MODEL_MANIFEST.json").read_text("utf-8-sig"))
    assert len(manifest["records"]) == 7
    for record in manifest["records"]:
        source = ROOT / "local-model" / record["file"]
        target = staged / record["file"]
        assert target.resolve().is_relative_to(staged.resolve())
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        assert hashlib.sha256(target.read_bytes()).hexdigest() == record["sha256"]
    report["pathRecovery"] = "Seven verified data files in isolated ASCII TEMP; original Unicode-path failure preserved"
    report["asciiStagingAndVerificationMs"] = (time.perf_counter() - start) * 1000
    start = time.perf_counter()
    tts = TurkishTTS.from_pretrained(staged, device="cpu", token=False)
    report["modelLoadMs"] = (time.perf_counter() - start) * 1000
    report["sampleRate"] = tts.sample_rate
    assert tts.sample_rate == 24000 and set(tts.voices) == {"male_1", "male_2", "male_3"}
    assert not tts._custom, "Human/custom voice cloning is prohibited"
    calls = 0
    for candidate in PLAN["candidates"]:
        for index, text in enumerate([" ".join(PLAN["demoTexts"])] + CORPUS):
            budget()
            calls += 1
            assert calls <= PLAN["maximumSyntheses"]
            path = ROOT / "audio-local" / (candidate["file"] if index == 0 else
                                          f"{candidate['name']}_test_{index - 1:02d}.wav")
            assert not path.exists(), "Never overwrite output evidence"
            prepared = tts.prepare(text, candidate["emotion"])
            first = None
            chunks = []
            cpu = time.process_time()
            start = time.perf_counter()
            for chunk in tts.stream(text, voice=candidate["voice"], emotion=candidate["emotion"], seed=PLAN["seed"]):
                if chunk.size and first is None:
                    first = (time.perf_counter() - start) * 1000
                chunks.append(chunk)
                budget()
            elapsed = (time.perf_counter() - start) * 1000
            cpu_ms = (time.process_time() - cpu) * 1000
            audio = np.concatenate(chunks)
            assert audio.size and np.isfinite(audio).all() and np.sqrt(np.mean(audio ** 2)) > 0.001
            save_wav(path, audio, tts.sample_rate)
            with wave.open(str(path), "rb") as wav:
                assert wav.getnchannels() == 1 and wav.getsampwidth() == 2 and wav.getnframes() == len(audio)
            report["rows"].append({"candidate": candidate["name"], "voice": candidate["voice"],
                "emotion": candidate["emotion"], "kind": "cold-voice-demo" if index == 0 else "warm-case",
                "case": index - 1, "file": path.relative_to(ROOT).as_posix(), "text": text,
                "preparedSentences": prepared, "inputSha256": hashlib.sha256(text.encode()).hexdigest(),
                "fileSha256": hashlib.sha256(path.read_bytes()).hexdigest(), "firstPcmMs": first,
                "totalMs": elapsed, "processCpuMs": cpu_ms, "memory": memory(),
                "durationSeconds": len(audio) / tts.sample_rate, "rms": float(np.sqrt(np.mean(audio ** 2))),
                "rawPeak": float(np.max(np.abs(audio))), "rawOverFullScaleSamples": int(np.sum(np.abs(audio) >= 1)),
                "nearFullScaleSamples": int(np.sum(np.abs(audio) >= 0.999)), "finite": True,
                "streamChunks": len(chunks), "pcmWaveValid": True})
            checkpoint()
            print(json.dumps({"candidate": candidate["name"], "case": index - 1,
                              "firstPcmMs": round(first, 2), "totalMs": round(elapsed, 2)}, ensure_ascii=False), flush=True)
        budget()
        calls += 1
        iterator = tts.stream(CORPUS[-1], voice=candidate["voice"], emotion=candidate["emotion"], seed=PLAN["seed"])
        chunk = next(iterator)
        start = time.perf_counter()
        iterator.close()
        cancel_ms = (time.perf_counter() - start) * 1000
        report["cancellation"].append({"candidate": candidate["name"], "closeAfterFirstChunkMs": cancel_ms,
            "firstChunkSamples": int(chunk.size), "scope": "isolated generator only; AYAS playback/echo NOT_RUN"})
        checkpoint()
    report["calls"] = calls
    assert calls == 54 and len(report["rows"]) == 51
    report["summary"] = []
    for candidate in PLAN["candidates"]:
        rows = [r for r in report["rows"] if r["candidate"] == candidate["name"]]
        warm = [r for r in rows if r["kind"] == "warm-case"]
        report["summary"].append({"candidate": candidate["name"], "voice": candidate["voice"], "warmN": len(warm),
            "coldVoiceFirstPcmMs": rows[0]["firstPcmMs"],
            "warmFirstPcmP50Ms": float(np.percentile([r["firstPcmMs"] for r in warm], 50)),
            "warmFirstPcmP95Ms": float(np.percentile([r["firstPcmMs"] for r in warm], 95)),
            "warmTotalP95Ms": float(np.percentile([r["totalMs"] for r in warm], 95)),
            "warmProcessCpuP50Ms": float(np.percentile([r["processCpuMs"] for r in warm], 50)),
            "warmProcessCpuP95Ms": float(np.percentile([r["processCpuMs"] for r in warm], 95)),
            "processPeakWorkingSetBytes": max(r["memory"]["peakWorkingSetBytes"] for r in rows),
            "rawOverFullScaleSamples": sum(r["rawOverFullScaleSamples"] for r in rows),
            "wavValidCount": len(rows), "ownerQualityGate": "NOT_RUN"})
    report["status"] = "PREPARED_OBJECTIVE_AUDIO_CHECKS_ONLY_OWNER_REVIEW_REQUIRED"
except BaseException as error:
    report["status"] = "FAIL"
    report["error"] = {"type": type(error).__name__, "message": str(error)}
    checkpoint()
    raise
finally:
    report["wallSeconds"] = time.perf_counter() - started
    if staged is not None:
        assert staged.resolve().is_relative_to(pathlib.Path(tempfile.gettempdir()).resolve())
        assert staged.name.startswith("ayas-tts-v2-")
        # Exact known files only; no recursive removal or shell path composition.
        for record in manifest["records"]:
            (staged / record["file"]).unlink(missing_ok=True)
        if (staged / "voices").is_dir():
            (staged / "voices").rmdir()
        staged.rmdir()
        report["temporaryModelCopiesRemoved"] = True
    checkpoint()
