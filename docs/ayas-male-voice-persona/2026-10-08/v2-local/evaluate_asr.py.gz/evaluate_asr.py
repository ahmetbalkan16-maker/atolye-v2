"""Fixed 19-clip intelligibility probe using existing local Whisper, no new STT dependency."""
import hashlib
import json
import pathlib
import re
import subprocess
import time

ROOT = pathlib.Path(__file__).resolve().parent
REPO = ROOT.parent.parent
RESULT = ROOT / "ASR_RESULTS.json"
assert not RESULT.exists(), "Preserve existing evidence"
audio_report = json.loads((ROOT / "LOCAL_RESULTS.json").read_text("utf-8"))
assert len(audio_report["rows"]) == 51
exe = REPO / "bin/whisper/blas/Release/whisper-cli.exe"
model = REPO / "bin/whisper/ggml-small.bin"
from pocket_tts_turkish.normalizer import normalize

def clean(text):
    text = text.translate(str.maketrans({"I": "ı", "İ": "i"})).lower()
    return re.sub(r"[^\w\s]", " ", text, flags=re.UNICODE).split()

def distance(left, right):
    previous = list(range(len(right) + 1))
    for i, value in enumerate(left, 1):
        current = [i]
        for j, other in enumerate(right, 1):
            current.append(min(current[-1] + 1, previous[j] + 1, previous[j - 1] + (value != other)))
        previous = current
    return previous[-1]

selected = [r for r in audio_report["rows"] if r["kind"] == "cold-voice-demo" or r["case"] in (0, 12, 13, 14, 15)]
assert len(selected) == 18
selected.append({"candidate": "PIPER_REFERENCE", "case": 0,
    "file": "../male-voice-persona/2026-10-08/ayas-calm-male-evaluation-0.wav",
    "text": "Merhaba. Ben AYAS. Size nasıl yardımcı olabilirim?"})
report = {"scope": "Existing Whisper small CPU2, raw synthetic audio; no prompts, training, live STT or wake changes",
          "maximumClips": 19, "threads": 2, "modelSha256": hashlib.sha256(model.read_bytes()).hexdigest(),
          "cliSha256": hashlib.sha256(exe.read_bytes()).hexdigest(), "rows": [],
          "limits": "ASR proxy only; transcription error is not proof of acoustic error, naturalness or /s/-versus-/z/ acceptance"}
started = time.perf_counter()
for index, row in enumerate(selected):
    assert time.perf_counter() - started < 300, "ASR wall budget"
    name = f"probe_{index:02d}"
    output = ROOT / "asr" / name
    path = (ROOT / row["file"]).resolve()
    args = [str(exe.relative_to(REPO)), "-m", str(model.relative_to(REPO)), "-ng", "-t", "2", "-l", "tr",
            "-nf", "-bo", "1", "-bs", "1", "-oj", "-otxt", "-of", str(output.relative_to(REPO)),
            str(path.relative_to(REPO))]
    start = time.perf_counter()
    completed = subprocess.run(args, cwd=REPO, capture_output=True, timeout=30)
    (ROOT / "asr" / f"{name}.stdout.log").write_bytes(completed.stdout)
    (ROOT / "asr" / f"{name}.stderr.log").write_bytes(completed.stderr)
    assert completed.returncode == 0 and output.with_suffix(".txt").exists(), "Whisper execution failed"
    transcript = output.with_suffix(".txt").read_text("utf-8").strip()
    reference = clean(normalize(row["text"]))
    recognized = clean(normalize(transcript))
    ref_chars = list(" ".join(reference))
    rec_chars = list(" ".join(recognized))
    report["rows"].append({"candidate": row["candidate"], "case": row["case"], "file": row["file"],
        "reference": row["text"], "transcript": transcript, "wordEdits": distance(reference, recognized),
        "referenceWords": len(reference), "wer": distance(reference, recognized) / len(reference),
        "cer": distance(ref_chars, rec_chars) / len(ref_chars),
        "ayasTokenRecognized": "ayas" in clean(transcript) if "AYAS" in row["text"] else None,
        "asrWallMs": (time.perf_counter() - start) * 1000, "scope": "ASR proxy, not owner listening PASS"})
    RESULT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"candidate": row["candidate"], "case": row["case"], "wer": report["rows"][-1]["wer"]}), flush=True)
report["wallSeconds"] = time.perf_counter() - started
report["status"] = "ASR_PROXIES_MEASURED_OWNER_LISTENING_REQUIRED"
RESULT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
