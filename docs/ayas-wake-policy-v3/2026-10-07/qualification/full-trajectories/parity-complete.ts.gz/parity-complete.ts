import fs from 'node:fs';import path from 'node:path';import * as ort from 'onnxruntime-web';import {WakeScoreDetector} from '../../src/components/brain/voice/wakeWordVoiceAdapter';
const root=process.cwd(),out=path.join(root,'.graphify/wake-policy-v3'),result=JSON.parse(fs.readFileSync(path.join(out,'complete-fit.json'),'utf8'));
function data(file:string){const b=fs.readFileSync(file);return new Float32Array(b.buffer.slice(b.byteOffset,b.byteOffset+b.length));}
async function main(){ort.env.wasm.numThreads=1;const session=await ort.InferenceSession.create(path.join(out,'complete-prototype.onnx'),{executionProviders:['wasm']});let maxError=0,frames=0,decisionMismatches=0;const rows=[];try{
 const original=data(path.join(root,'.graphify/wake-policy-v2/multi/prototype-features.f32')),complete=data(path.join(out,'complete-negative/features.f32'));
 for(const c of result.tests){const buffer=c.source?.startsWith('NEW')?complete:original,cpu=new WakeScoreDetector(),wasm=new WakeScoreDetector();let a=0,b=0;
  for(let i=0;i<c.windows;i++){const x=buffer.subarray((c.offset+i)*1536,(c.offset+i+1)*1536),r=await session.run({[session.inputNames[0]]:new ort.Tensor('float32',x,[1,16,96])}),s=Number(r[session.outputNames[0]].data[0]);if(!Number.isFinite(s))throw Error('non-finite WASM score');maxError=Math.max(maxError,Math.abs(s-c.scores[i]));frames++;if(cpu.observe(c.scores[i]))a++;if(wasm.observe(s))b++;}
  if(a!==b){decisionMismatches++;rows.push({id:c.id,text:c.text,source:c.source,cpu:a,wasm:b});}
 }
 const status=maxError<0.00001&&decisionMismatches===0?'PASS':'FAIL';console.log(JSON.stringify({status,frames,trajectories:result.tests.length,maxAbsoluteError:maxError,decisionMismatches,rows,execution:'REAL existing onnxruntime-web WASM one thread vs saved CPU arithmetic',numericTolerance:0.00001,detector:'UNCHANGED actual WakeScoreDetector',qualification:'numeric/kernel parity ONLY; not acoustic acceptance',independentHuman:false}));if(status==='FAIL')process.exitCode=1;
}finally{await session.release();}}
main().catch(e=>{console.error(e);process.exitCode=1;});
