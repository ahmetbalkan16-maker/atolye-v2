const fs=require('fs');let code=fs.readFileSync('.graphify/wake-policy-v3/finetune-remaining.py','utf8');
code=code.replaceAll('finetune-', 'complete-').replace("out/'corrected-prototype.onnx'", "out/'finetune-prototype.onnx'");
code=code.replace("full=np.fromfile(out/'full-training-negatives.f32',dtype=np.float32).reshape(-1,1536)",`full_old=np.fromfile(out/'full-training-negatives.f32',dtype=np.float32).reshape(-1,1536)
complete_clips=json.loads((out/'complete-negative/clips.json').read_text(encoding='utf-8'))['clips']
complete_features=np.memmap(out/'complete-negative/features.f32',dtype=np.float32,mode='r').reshape(-1,1536)
train_offsets=[i for c in complete_clips if c['split']=='train-only' for i in range(c['offset'],c['offset']+c['windows'])]
full=np.concatenate([full_old,np.asarray(complete_features[train_offsets])])`);
code=code.replace('batch[p>=.02]', 'batch[p>=.0001]').replace('easy_background=background[::16]', 'easy_background=background[::4]');
code=code.replace('range(8)', 'range(16)').replace("'fixedEpochs':8", "'fixedEpochs':16").replace('n_iter_=8','n_iter_=16').replace("'maxIterations':8", "'maxIterations':16");
code=code.replace("'trainingClips':sum(c['split']=='train' for c in clips)", "'trainingClips':sum(c['split']=='train' for c in clips)+sum(c['split']=='train-only' for c in complete_clips), 'heldOutSourceCounts':{'previous':480,'newCompleteNegatives':168}");
code=code.replace('tests=[]',`tests=[]
for c in complete_clips:
 if c['split']=='held-out':
  p=predict(np.asarray(complete_features[c['offset']:c['offset']+c['windows']]));n=decisions(p)
  tests.append({**c,'source':'NEW full-trajectory held-out negative','candidatePeak':float(np.max(p)),'decisions':n,'status':'PASS' if n==0 else 'FAIL','scores':p.tolist()})`);
code=code.replace('resume corrected64-unit weights; all training-only negative score frames, train-only current-head background mining, balanced positives and5x hard-negative loss; fixed8 epochs; held-out labels untouched', 'resume finetune64-unit weights;672 NEW complete train-only negative trajectories plus previous full negatives; train-only current-head background cutoff0.0001; balanced positives and5x hard-negative loss; fixed16 epochs; all held-out sources excluded from fit; no threshold changes');
fs.writeFileSync('.graphify/wake-policy-v3/fit-complete.py',code);
