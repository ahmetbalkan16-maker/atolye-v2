import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {execFileSync} from 'node:child_process';import {createHash} from 'node:crypto';import * as ort from 'onnxruntime-web';
import {OpenWakeWordRunner,type WakeSession} from '../../src/components/brain/voice/wake/openWakeWordRunner';
const root=process.cwd(),out=path.join(root,'.graphify/wake-policy-v3/complete-negative'),work=fs.mkdtempSync(path.join(os.tmpdir(),'ayas-v3-complete-negative-'));
const models={wakewordUrl:path.join(root,'public/wake/ayas.onnx'),melspectrogramUrl:path.join(root,'public/wake/melspectrogram.onnx'),embeddingUrl:path.join(root,'public/wake/embedding_model.onnx')};
let rows:Float32Array[]=[];const r=new OpenWakeWordRunner({...models,createSession:async(url,options)=>{const s=await ort.InferenceSession.create(url,options);if(url!==models.wakewordUrl)return s as WakeSession;return{inputNames:s.inputNames,outputNames:s.outputNames,release:()=>s.release(),run:async(feeds)=>{rows.push(new Float32Array(feeds[s.inputNames[0]].data as Float32Array));return s.run(feeds);}};}});
const texts=['HAYAZ','ayasız','ayaslı','ayazlı','ayasa','hayat','beyaz','yavaş','merhaba','ya','ay','ayak','ayran','hayır','saat kaç','kapıyı kapat','bugün hava çok güzel','teşekkür ederim','merhaba merhaba merhaba','hayat hayat hayat','HAYAZ HAYAZ HAYAZ'];
function wav(file:string){const b=fs.readFileSync(file);for(let off=12;off+8<=b.length;){const size=b.readUInt32LE(off+4);if(b.toString('ascii',off,off+4)==='data'){const pcm=new Float32Array(size/2);for(let i=0;i<pcm.length;i++)pcm[i]=b.readInt16LE(off+8+i*2)/32768;return pcm;}off+=8+size+size%2;}throw Error('pcm missing');}
async function main(){fs.mkdirSync(out,{recursive:true});fs.mkdirSync(path.join(out,'held-pcm'));const binary=fs.openSync(path.join(out,'features.f32'),'wx'),clips=[];try{
 fs.cpSync(path.join(root,'bin/piper'),path.join(work,'piper'),{recursive:true});await r.init();await r.warmUp();
 for(const text of texts)for(let n=0;n<40;n++){
  const raw=path.join(work,'raw.wav'),file=path.join(work,'clip.wav'),length=[.8,1,1.2][n%3],pitch=[.90,1,1.1,1.2][n%4];
  execFileSync(path.join(work,'piper/piper.exe'),['--model',path.join(work,'piper/tr_TR-dfki-medium.onnx'),'--espeak_data',path.join(work,'piper/espeak-ng-data'),'--output_file',raw,'--length_scale',String(length)],{input:text,cwd:path.join(work,'piper'),windowsHide:true,stdio:['pipe','ignore','ignore']});
  execFileSync('ffmpeg',['-nostdin','-loglevel','error','-y','-i',raw,'-af',`asetrate=22050*${pitch},aresample=16000,volume=${.4+(n%4)*.2}`,'-ac','1','-ar','16000','-c:a','pcm_s16le',file],{stdio:'ignore',windowsHide:true});
  const source=wav(file),lead=[0,1280,6400,11200][n%4],pcm=new Float32Array(Math.ceil((source.length+lead+32000)/1280)*1280);pcm.set(source,lead);r.reset();rows=[];for(let off=0;off<pcm.length;off+=1280)await r.accept(pcm.subarray(off,off+1280));
  const id=clips.length,offset=fs.fstatSync(binary).size/(1536*4),split=n<32?'train-only':'held-out';for(const row of rows)fs.writeSync(binary,Buffer.from(row.buffer));
  if(split==='held-out')fs.writeFileSync(path.join(out,'held-pcm',`${id}.f32`),Buffer.from(pcm.buffer));
  clips.push({id,text,n,split,label:0,length,pitch,leadMs:lead/16,offset,windows:rows.length,pcmSha256:createHash('sha256').update(Buffer.from(pcm.buffer)).digest('hex')});
  if((id+1)%40===0){fs.writeFileSync(path.join(out,'progress.json'),JSON.stringify({clips:clips.length,text,windows:fs.fstatSync(binary).size/(1536*4)}));console.log(JSON.stringify({clips:clips.length,text}));}
 }
 const hashes=new Set(clips.filter(c=>c.split==='train-only').map(c=>c.pcmSha256));if(clips.some(c=>c.split==='held-out'&&hashes.has(c.pcmSha256)))throw Error('train/held PCM overlap');
 fs.writeFileSync(path.join(out,'clips.json'),JSON.stringify({featureSize:1536,clips,selection:'ALL real-WASM score frames, NO legacy peak filtering',split:'fixed n<32 train-only, n>=32 held-out BEFORE fitting',sourceOverlap:0,independentHuman:false},null,2)+'\n');console.log(JSON.stringify({status:'PASS',clips:clips.length,training:672,heldOut:168,windows:fs.fstatSync(binary).size/(1536*4)}));
}finally{fs.closeSync(binary);r.dispose();const resolved=path.resolve(work);if(resolved.startsWith(path.resolve(os.tmpdir())+path.sep)&&path.basename(resolved).startsWith('ayas-v3-complete-negative-'))fs.rmSync(resolved,{recursive:true,force:true});}}
main().catch(e=>{console.error(e);process.exitCode=1;});
