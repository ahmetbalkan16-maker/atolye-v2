from threadpoolctl import threadpool_limits
import json,pathlib,time,hashlib
import numpy as np
import onnx,onnxruntime as ort
from onnx import helper,TensorProto,numpy_helper
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
threadpool_limits(4)
root=pathlib.Path.cwd();out=root/'.graphify/wake-policy-v3';source=root/'.graphify/wake-policy-v2/multi'
clips=json.loads((source/'prototype-clips.json').read_text(encoding='utf-8'))['clips'];features=np.fromfile(source/'prototype-features.f32',dtype=np.float32).reshape(-1,1536)
options=ort.SessionOptions();options.intra_op_num_threads=2;options.inter_op_num_threads=1
old=ort.InferenceSession(str(root/'public/wake/ayas.onnx'),options,providers=['CPUExecutionProvider']);input_name=old.get_inputs()[0].name
accepted={'AYAS','AYAZ','HAYAS','ayas merhaba','ayaz merhaba','hayas merhaba'}
silent_features=np.fromfile(out/'silent-features.f32',dtype=np.float32).reshape(-1,1536)
silent_hashes={hashlib.sha256(v.tobytes()).hexdigest() for v in silent_features}
contradictions=json.loads((out/'label-conflicts.json').read_text(encoding='utf-8'))['conflicts']
assert all(c['first']['featureSha256'] in silent_hashes for c in contradictions), 'non-silent label contradiction must be resolved before fitting'
silence_relabels=0
indices=[];labels=[]
for c in clips:
 c['v3Label']=int(c['text'] in accepted)
 if c['split']=='train':
  values=features[c['offset']:c['offset']+c['windows']]
  if c['label']==1:target=np.ones(len(values),dtype=np.int32)
  elif c['v3Label']==1:
   scores=np.array([old.run(None,{input_name:v.reshape(1,16,96)})[0].flat[0] for v in values]);peak=int(np.argmax(scores));target=np.array([int(abs(i-peak)<=2) for i in range(len(values))])
  else:target=np.zeros(len(values),dtype=np.int32)
  for i,v in enumerate(values):
   if target[i] and hashlib.sha256(v.tobytes()).hexdigest() in silent_hashes:target[i]=0;silence_relabels+=1
  indices.extend(range(c['offset'],c['offset']+c['windows']));labels.extend(target.tolist())
validation=np.load(root/'.venv-wake/wake-data/validation_set_features.npy',mmap_mode='r');split=int(len(validation)*.55)
mining_models=[]
for file in ['mlp-prototype.onnx','broad/mlp-prototype.onnx','multi/mlp-prototype.onnx']:
 graph=onnx.load(root/'.graphify/wake-policy-v2'/file).graph
 weights={t.name:numpy_helper.to_array(t) for t in graph.initializer};mining_models.append(weights)
def mining_predict(batch,weights):
 logit=np.maximum(batch@weights['w1']+weights['b1'],0)@weights['w2']+weights['b2']
 return (1/(1+np.exp(-np.clip(logit,-80,80)))).reshape(-1)
hard=[];sampled=[];mining_started=time.perf_counter()
for start in range(0,split-16,2048):
 stop=min(start+2048,split-16);batch=np.stack([np.asarray(validation[i:i+16]).reshape(-1) for i in range(start,stop)]).astype(np.float32)
 scores=np.max(np.stack([mining_predict(batch,weights) for weights in mining_models]),axis=0)
 hard.extend(batch[scores>=.009]);sampled.extend(batch[np.arange(start,stop)%8==0])
(out/'finetune-mining-progress.json').write_text(json.dumps({'phase':'mining-complete','hard':len(hard),'sampled':len(sampled),'silenceRelabels':silence_relabels,'miningMs':(time.perf_counter()-mining_started)*1000}),encoding='utf-8')
background=np.asarray(hard+sampled,dtype=np.float32)
x=np.concatenate([features[indices],background]);y=np.concatenate([np.asarray(labels),np.zeros(len(background))]);rng=np.random.default_rng(2707)
scaler=StandardScaler().fit(x);scaled=scaler.transform(x);positive=np.flatnonzero(y==1);negative=np.flatnonzero(y==0)
balanced=np.concatenate([negative,rng.choice(positive,len(negative),replace=True)]);rng.shuffle(balanced)
import torch
from types import SimpleNamespace
torch.set_num_threads(4);torch.set_num_interop_threads(1);torch.manual_seed(2707)
initial={t.name:numpy_helper.to_array(t) for t in onnx.load(out/'corrected-prototype.onnx').graph.initializer}
net=torch.nn.Sequential(torch.nn.Linear(1536,64),torch.nn.ReLU(),torch.nn.Linear(64,1))
with torch.no_grad():
 net[0].weight.copy_(torch.from_numpy((initial['w1']*scaler.scale_[:,None]).astype(np.float32).T.copy()))
 net[0].bias.copy_(torch.from_numpy((initial['b1']+scaler.mean_@initial['w1']).astype(np.float32)))
 net[2].weight.copy_(torch.from_numpy(initial['w2'].T.copy()));net[2].bias.copy_(torch.from_numpy(initial['b2'].copy()))
def initial_predict(batch):return (1/(1+np.exp(-np.clip(np.maximum(batch@initial['w1']+initial['b1'],0)@initial['w2']+initial['b2'],-80,80)))).reshape(-1)
initial_train=initial_predict(x)
audit={'positiveHardMisses':int(np.sum(initial_train[y==1]<.7)),'negativeHardErrors':int(np.sum(initial_train[y==0]>=.7)),'fullTrainingWords':len(indices),'trainingOnly':True}
(out/'finetune-initial-training-audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
full=np.fromfile(out/'full-training-negatives.f32',dtype=np.float32).reshape(-1,1536)
new_hard=[]
for start in range(0,split-16,2048):
 stop=min(start+2048,split-16);batch=np.stack([np.asarray(validation[i:i+16]).reshape(-1) for i in range(start,stop)]).astype(np.float32);p=initial_predict(batch);new_hard.extend(batch[p>=.02])
new_hard=np.asarray(new_hard,dtype=np.float32).reshape(-1,1536)
positive_values=x[y==1];local_negative=x[:len(indices)][y[:len(indices)]==0];easy_background=background[::16]
fine_raw=np.concatenate([positive_values,local_negative,full,new_hard,easy_background]);fine_y=np.concatenate([np.ones(len(positive_values)),np.zeros(len(fine_raw)-len(positive_values))]).astype(np.float32)
fine_weights=np.ones(len(fine_raw),dtype=np.float32);fine_weights[(fine_y==0)&(initial_predict(fine_raw)>=.1)]=5
fine_scaled=scaler.transform(fine_raw).astype(np.float32);positive=np.flatnonzero(fine_y==1);negative=np.flatnonzero(fine_y==0)
rng=np.random.default_rng(8927);fine_indices=np.concatenate([negative,rng.choice(positive,len(negative),replace=True)])
tx=torch.from_numpy(fine_scaled);ty=torch.from_numpy(fine_y);tw=torch.from_numpy(fine_weights);optimizer=torch.optim.AdamW(net.parameters(),lr=.0003,weight_decay=.0001)
started=time.perf_counter();losses=[]
for epoch in range(8):
 rng.shuffle(fine_indices);total=0.0
 for begin in range(0,len(fine_indices),256):
  batch=fine_indices[begin:begin+256];optimizer.zero_grad();logit=net(tx[batch]).flatten();loss=(torch.nn.functional.binary_cross_entropy_with_logits(logit,ty[batch],reduction='none')*tw[batch]).mean();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),1.0);optimizer.step();total+=float(loss.detach())*len(batch)
 losses.append(total/len(fine_indices));(out/'finetune-progress.json').write_text(json.dumps({'phase':'fine-tuning','epoch':epoch+1,'fixedEpochs':8,'trainingLoss':losses[-1],'trainingWindows':len(fine_raw),'balancedWindows':len(fine_indices),'newTrainingHardBackgrounds':len(new_hard)}),encoding='utf-8')
with torch.no_grad():
 ws=net[0].weight.numpy().T.copy();bs=net[0].bias.numpy().copy();w2=net[2].weight.numpy().T.copy();b2=net[2].bias.numpy().copy()
w1=(ws/scaler.scale_[:,None]).astype(np.float32);b1=(bs-(scaler.mean_/scaler.scale_)@ws).astype(np.float32);model=SimpleNamespace(n_iter_=8)

def predict(x):return (1/(1+np.exp(-np.clip(np.maximum(x@w1+b1,0)@w2+b2,-80,80)))).reshape(-1)
def decisions(scores):
 count=0;ring=[]
 for score in scores:
  ring.append(float(score));ring=ring[-7:]
  if score>=.7 or sum(s>=.6 for s in ring)>=3 or (max(ring)>=.67 and sum(s>=.63 for s in ring)>=2):count+=1;ring=[]
 return count
tests=[]
for c in clips:
 if c['split']=='held-out':
  p=predict(features[c['offset']:c['offset']+c['windows']]);n=decisions(p)
  tests.append({**c,'candidatePeak':float(np.max(p)),'decisions':n,'status':'PASS' if (n>0)==bool(c['v3Label']) else 'FAIL','scores':p.tolist()})
false_frames=0;max_background=0;n_background=0;bg_decisions=0;all_bg_scores=[]
for start in range(split,len(validation)-16,2048):
 stop=min(start+2048,len(validation)-16);batch=np.stack([np.asarray(validation[i:i+16]).reshape(-1) for i in range(start,stop)]).astype(np.float32);p=predict(batch);false_frames+=int(np.sum(p>=.7));max_background=max(max_background,float(np.max(p)));n_background+=len(p);all_bg_scores.extend(p.tolist())
bg_decisions=decisions(all_bg_scores)
np.asarray(all_bg_scores,dtype=np.float32).tofile(out/'finetune-bg-scores.f32')
nodes=[helper.make_node('Flatten',['input'],['flat'],axis=1),helper.make_node('MatMul',['flat','w1'],['dot1']),helper.make_node('Add',['dot1','b1'],['hidden']),helper.make_node('Relu',['hidden'],['relu']),helper.make_node('MatMul',['relu','w2'],['dot2']),helper.make_node('Add',['dot2','b2'],['logit']),helper.make_node('Sigmoid',['logit'],['score'])]
graph=helper.make_graph(nodes,'ayas-owner-v3-private-remaining-gate-candidate',[helper.make_tensor_value_info('input',TensorProto.FLOAT,[1,16,96])],[helper.make_tensor_value_info('score',TensorProto.FLOAT,[1,1])],[numpy_helper.from_array(a,n) for a,n in [(w1,'w1'),(b1,'b1'),(w2,'w2'),(b2,'b2')]])
artifact=helper.make_model(graph,opset_imports=[helper.make_opsetid('',13)],producer_name='AYAS bounded private qualification');artifact.ir_version=8;onnx.checker.check_model(artifact);onnx.save(artifact,out/'finetune-prototype.onnx')
failures=[t for t in tests if t['status']=='FAIL'];result={'status':'FAIL' if failures or bg_decisions else 'PASS','policy':'owner-v3','purpose':'remaining suffix/ordinary false positives and AYAZ reliability; NOT HAYAS discrimination','trainingClips':sum(c['split']=='train' for c in clips),'heldOutClips':len(tests),'trainingWindows':len(x),'hardMinedTrainingOnly':len(hard),'heldOutFailures':failures,'tests':tests,'negativeEmbeddingValidation':{'source':'existing precomputed negative features','unseenFrames':n_background,'falseWakeFrames':false_frames,'decisions':bg_decisions,'maxScore':max_background,'stride':1,'rawAudioReplay':False},'fitAndEvaluationMs':(time.perf_counter()-started)*1000,'iterations':model.n_iter_,'hyperparameters':{'hidden':64,'alpha':.1,'hard':.7,'soft':.6,'softVotes':'3/7','near':.67,'nearVotes':'.63 x2','maxIterations':8,'optimizer':'AdamW f32 lr0.0003','hardNegativeWeight':5},'modelBytes':(out/'finetune-prototype.onnx').stat().st_size,'productionInstalled':False,'silenceRelabels':silence_relabels,'trainingRecipe':'resume corrected64-unit weights; all training-only negative score frames, train-only current-head background mining, balanced positives and5x hard-negative loss; fixed8 epochs; held-out labels untouched','fineTrainingWindows':len(fine_raw),'newHardTrainingBackgrounds':len(new_hard),'trainingLosses':losses,'rawWasmReplay':'SEPARATE_REQUIRED','independentHumanQualification':False}
(out/'finetune-fit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k not in ['tests','heldOutFailures']}));print('failed clip ids:',[t['id'] for t in failures]);raise SystemExit(1 if failures or bg_decisions else 0)
