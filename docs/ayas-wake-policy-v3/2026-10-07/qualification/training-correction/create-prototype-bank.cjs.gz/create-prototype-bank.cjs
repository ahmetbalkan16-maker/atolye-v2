const fs=require('node:fs');let code=fs.readFileSync('.graphify/wake-policy-v3/fit-remaining-corrected.py','utf8');const stop=code.indexOf('scaler=StandardScaler()');if(stop<0)throw Error('prefix missing');code=code.slice(0,stop).replaceAll("out/'corrected-progress.json'","out/'bank-mining-progress.json'");
code+=`
from sklearn.cluster import MiniBatchKMeans
initial={t.name:numpy_helper.to_array(t) for t in onnx.load(out/'finetune-prototype.onnx').graph.initializer}
teacher={t.name:numpy_helper.to_array(t) for t in onnx.load(out/'corrected-prototype.onnx').graph.initializer}
def hidden(batch):return np.maximum(batch@initial['w1']+initial['b1'],0)
def dense(batch,weights=initial):return (1/(1+np.exp(-np.clip(np.maximum(batch@weights['w1']+weights['b1'],0)@weights['w2']+weights['b2'],-80,80)))).reshape(-1)
full=np.fromfile(out/'full-training-negatives.f32',dtype=np.float32).reshape(-1,1536)
negative_raw=np.concatenate([x[y==0],full]);positive_raw=x[y==1]
hx=hidden(x);hfull=hidden(full);hscale=np.std(hx,axis=0);hscale[hscale<.0001]=1
positive=np.unique((hidden(positive_raw)/hscale).astype(np.float32),axis=0)
negative_hidden=np.concatenate([hx[y==0],hfull])/hscale
anchors=np.unique(negative_hidden[dense(negative_raw,teacher)>=.1].astype(np.float32),axis=0)
assert len(anchors)<=2048,'prototype budget exceeded; do not truncate silently'
started=time.perf_counter();kmeans=MiniBatchKMeans(n_clusters=2048,batch_size=4096,max_iter=50,n_init=1,random_state=2707).fit(negative_hidden)
negative=np.concatenate([kmeans.cluster_centers_,anchors]).astype(np.float32)
def predict(batch):
 h=(hidden(batch)/hscale).astype(np.float32)
 # Chunked direct differences avoid cancellation at exact template equality.
 dp=np.full(len(h),np.inf,dtype=np.float32);dn=dp.copy()
 for begin in range(0,len(positive),256):dp=np.minimum(dp,np.sum((h[:,None,:]-positive[None,begin:begin+256,:])**2,axis=2).min(axis=1))
 for begin in range(0,len(negative),256):dn=np.minimum(dn,np.sum((h[:,None,:]-negative[None,begin:begin+256,:])**2,axis=2).min(axis=1))
 return dense(batch)*(dp<dn)
def decisions(scores):
 count=0;ring=[]
 for score in scores:
  ring.append(float(score));ring=ring[-7:]
  if score>=.7 or sum(s>=.6 for s in ring)>=3 or (max(ring)>=.67 and sum(s>=.63 for s in ring)>=2):count+=1;ring=[]
 return count
tests=[]
for c in clips:
 if c['split']=='held-out':
  p=predict(features[c['offset']:c['offset']+c['windows']]);n=decisions(p);tests.append({**c,'candidatePeak':float(np.max(p)),'decisions':n,'status':'PASS' if (n>0)==bool(c['v3Label']) else 'FAIL','scores':p.tolist()})
all_bg=[];n_background=0
for begin in range(split,len(validation)-16,256):
 stop=min(begin+256,len(validation)-16);batch=np.stack([np.asarray(validation[i:i+16]).reshape(-1) for i in range(begin,stop)]).astype(np.float32);p=predict(batch);all_bg.extend(p.tolist());n_background+=len(p)
np.asarray(all_bg,dtype=np.float32).tofile(out/'bank-bg-scores.f32');bg_decisions=decisions(all_bg)
nodes=[helper.make_node('Flatten',['input'],['flat'],axis=1),helper.make_node('MatMul',['flat','w1'],['dot1']),helper.make_node('Add',['dot1','b1'],['hidden']),helper.make_node('Relu',['hidden'],['relu']),helper.make_node('MatMul',['relu','w2'],['dot2']),helper.make_node('Add',['dot2','b2'],['logit']),helper.make_node('Sigmoid',['logit'],['base_score']),helper.make_node('Div',['relu','hscale'],['whitened']),helper.make_node('Unsqueeze',['whitened'],['context'],axes=[1])]
for tag in ['positive','negative']:
 nodes.extend([helper.make_node('Sub',['context',tag],[tag+'_delta']),helper.make_node('Mul',[tag+'_delta',tag+'_delta'],[tag+'_squared']),helper.make_node('ReduceSum',[tag+'_squared'],[tag+'_distance'],axes=[2],keepdims=0),helper.make_node('ReduceMin',[tag+'_distance'],[tag+'_nearest'],axes=[1],keepdims=1)])
nodes.extend([helper.make_node('Less',['positive_nearest','negative_nearest'],['supported']),helper.make_node('Cast',['supported'],['gate'],to=TensorProto.FLOAT),helper.make_node('Mul',['base_score','gate'],['score'])])
constants=[numpy_helper.from_array(initial[n],n) for n in ['w1','b1','w2','b2']]+[numpy_helper.from_array(hscale.astype(np.float32),'hscale'),numpy_helper.from_array(positive[None,:,:],'positive'),numpy_helper.from_array(negative[None,:,:],'negative')]
graph=helper.make_graph(nodes,'ayas-owner-v3-local-prototype-evidence',[helper.make_tensor_value_info('input',TensorProto.FLOAT,[1,16,96])],[helper.make_tensor_value_info('score',TensorProto.FLOAT,[1,1])],constants)
artifact=helper.make_model(graph,opset_imports=[helper.make_opsetid('',11)],producer_name='AYAS bounded local qualification');artifact.ir_version=8;onnx.checker.check_model(artifact);onnx.save(artifact,out/'bank-prototype.onnx')
failures=[t for t in tests if t['status']=='FAIL'];result={'status':'FAIL' if failures or bg_decisions else 'PASS','policy':'owner-v3','trainingOnlyPrototypeCounts':{'positive':len(positive),'negativeCentroids':2048,'exactHardNegativeAnchors':len(anchors)},'heldOutClips':len(tests),'heldOutFailures':failures,'tests':tests,'negativeEmbeddingValidation':{'unseenFrames':n_background,'decisions':bg_decisions,'falseWakeFrames':int(np.sum(np.asarray(all_bg)>=.7)),'maxScore':max(all_bg),'stride':1,'rawAudioReplay':False},'rules':'retain real fine-head score only if nearest positive prototype is closer than nearest negative; ties fail closed; no threshold/vote/cooldown change','fitAndEvaluationMs':(time.perf_counter()-started)*1000,'modelBytes':(out/'bank-prototype.onnx').stat().st_size,'productionInstalled':False,'independentHumanQualification':False,'rawWasmReplay':'SEPARATE_REQUIRED'}
(out/'bank-fit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\\n',encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k not in ['tests','heldOutFailures']}));print('failed ids:',[t['id'] for t in failures]);raise SystemExit(1 if failures or bg_decisions else 0)
`;fs.writeFileSync('.graphify/wake-policy-v3/fit-prototype-bank.py',code);console.log('Created train-only nearest-prototype evidence candidate; all prior FAILs/weights preserved.');
