const fs=require('node:fs');let code=fs.readFileSync('.graphify/wake-policy-v3/fit-remaining-corrected.py','utf8');const start=code.indexOf('started=time.perf_counter();model='),end=code.indexOf('\ndef predict(x)',start);if(start<0||end<0)throw Error('fit block missing');
const block=`import torch
from types import SimpleNamespace
torch.set_num_threads(4);torch.set_num_interop_threads(1);torch.manual_seed(2707)
initial={t.name:numpy_helper.to_array(t) for t in onnx.load(out/'corrected-prototype.onnx').graph.initializer}
net=torch.nn.Sequential(torch.nn.Linear(1536,64),torch.nn.ReLU(),torch.nn.Linear(64,1))
with torch.no_grad():
 net[0].weight.copy_(torch.from_numpy((initial['w1']*scaler.scale_[:,None]).astype(np.float32).T.copy()))
 net[0].bias.copy_(torch.from_numpy((initial['b1']+scaler.mean_@initial['w1']).astype(np.float32)))
 net[2].weight.copy_(torch.from_numpy(initial['w2'].T.copy()));net[2].bias.copy_(torch.from_numpy(initial['b2'].copy()))
def initial_predict(batch):return (1/(1+np.exp(-np.clip(np.maximum(batch@initial['w1']+initial['b1'],0)@initial['w2']+initial['b2'],-80,80)))).reshape(-1)
initial_train=initial_predict(x)
audit={'positiveHardMisses':int(np.sum(initial_train[y==1]<.7)),'negativeHardErrors':int(np.sum(initial_train[y==0]>=.7)),'fullTrainingWords':len(indices),'trainingOnly':True}
(out/'finetune-initial-training-audit.json').write_text(json.dumps(audit,indent=2)+'\\n',encoding='utf-8')
full=np.fromfile(out/'full-training-negatives.f32',dtype=np.float32).reshape(-1,1536)
new_hard=[]
for start in range(0,split-16,2048):
 stop=min(start+2048,split-16);batch=np.stack([np.asarray(validation[i:i+16]).reshape(-1) for i in range(start,stop)]).astype(np.float32);p=initial_predict(batch);new_hard.extend(batch[p>=.02])
new_hard=np.asarray(new_hard,dtype=np.float32).reshape(-1,1536)
positive_values=x[y==1];local_negative=x[:len(indices)][y[:len(indices)]==0];easy_background=background[::16]
fine_raw=np.concatenate([positive_values,local_negative,full,new_hard,easy_background]);fine_y=np.concatenate([np.ones(len(positive_values)),np.zeros(len(fine_raw)-len(positive_values))]).astype(np.float32)
fine_weights=np.ones(len(fine_raw),dtype=np.float32);fine_weights[(fine_y==0)&(initial_predict(fine_raw)>=.1)]=5
fine_scaled=scaler.transform(fine_raw).astype(np.float32);positive=np.flatnonzero(fine_y==1);negative=np.flatnonzero(fine_y==0)
rng=np.random.default_rng(8927);fine_indices=np.concatenate([negative,rng.choice(positive,len(negative),replace=True)])
tx=torch.from_numpy(fine_scaled);ty=torch.from_numpy(fine_y);tw=torch.from_numpy(fine_weights);optimizer=torch.optim.AdamW(net.parameters(),lr=.0003,weight_decay=.0001)
started=time.perf_counter();losses=[]
for epoch in range(8):
 rng.shuffle(fine_indices);total=0.0
 for begin in range(0,len(fine_indices),256):
  batch=fine_indices[begin:begin+256];optimizer.zero_grad();logit=net(tx[batch]).flatten();loss=(torch.nn.functional.binary_cross_entropy_with_logits(logit,ty[batch],reduction='none')*tw[batch]).mean();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),1.0);optimizer.step();total+=float(loss.detach())*len(batch)
 losses.append(total/len(fine_indices));(out/'finetune-progress.json').write_text(json.dumps({'phase':'fine-tuning','epoch':epoch+1,'fixedEpochs':8,'trainingLoss':losses[-1],'trainingWindows':len(fine_raw),'balancedWindows':len(fine_indices),'newTrainingHardBackgrounds':len(new_hard)}),encoding='utf-8')
with torch.no_grad():
 ws=net[0].weight.numpy().T.copy();bs=net[0].bias.numpy().copy();w2=net[2].weight.numpy().T.copy();b2=net[2].bias.numpy().copy()
w1=(ws/scaler.scale_[:,None]).astype(np.float32);b1=(bs-(scaler.mean_/scaler.scale_)@ws).astype(np.float32);model=SimpleNamespace(n_iter_=8)
`;
code=code.slice(0,start)+block+code.slice(end);
code=code.replaceAll("out/'corrected-progress.json'","out/'finetune-mining-progress.json'").replaceAll('corrected-bg-scores.f32','finetune-bg-scores.f32').replaceAll("out/'corrected-prototype.onnx'","out/'finetune-prototype.onnx'").replaceAll('corrected-fit.json','finetune-fit.json');
// Restore the immutable initial checkpoint load after replacing output names.
code=code.replace("onnx.load(out/'finetune-prototype.onnx')","onnx.load(out/'corrected-prototype.onnx')");
code=code.replace("'maxIterations':60","'maxIterations':8,'optimizer':'AdamW f32 lr0.0003','hardNegativeWeight':5");
code=code.replace("'trainingRecipe':'known pure-silence vectors forced negative; vectorized training-only mining; 4-thread64-unit head max60 epochs; no held-out label change'","'trainingRecipe':'resume corrected64-unit weights; all training-only negative score frames, train-only current-head background mining, balanced positives and5x hard-negative loss; fixed8 epochs; held-out labels untouched','fineTrainingWindows':len(fine_raw),'newHardTrainingBackgrounds':len(new_hard),'trainingLosses':losses");
fs.writeFileSync('.graphify/wake-policy-v3/finetune-remaining.py',code);console.log('Created fixed8-epoch existing-head fine-tune; corrected FAIL/model unchanged.');
