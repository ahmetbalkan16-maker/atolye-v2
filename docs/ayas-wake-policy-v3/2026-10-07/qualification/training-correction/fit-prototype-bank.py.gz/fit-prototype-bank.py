from threadpoolctl import threadpool_limits
import json,pathlib,time,hashlib
import numpy as np
import onnx,onnxruntime as ort
from onnx import helper,TensorProto,numpy_helper
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
threadpool_limits(4)
root=pathlib.Path.cwd();out=root/'.graphify/wake-policy-v3';source=root/'.graphify/wake-policy-v2/multi'
clips=json.loads((source/'prototype-clips.json').read_text(encoding='utf-8'))['clips'];features=np.fromfile(source/'prototype-features.f32',dtype=np.float32).reshape(-1,1536)
options=ort.SessionOptions();options.intra_op_num_threads=2;options.inter_op_num_threads=1
old=ort.InferenceSession(str(root/'public/wake/ayas.onnx'),options,providers=['CPUExecutionProvider']);input_name=old.get_inputs()[0].name
accepted={'AYAS','AYAZ','HAYAS','ayas merhaba','ayaz merhaba','hayas merhaba'}
silent_features=np.fromfile(out/'silent-features.f32',dtype=np.float32).reshape(-1,1536)
silent_hashes={hashlib.sha256(v.tobytes()).hexdigest() for v in silent_features}
contradictions=json.loads((out/'label-conflicts.json').read_text(encoding='utf-8'))['conflicts']
assert all(c['first']['featureSha256'] in silent_hashes for c in contradictions), 'non-silent label contradiction must be resolved before fitting'
silence_relabels=0
indices=[];labels=[]
for c in clips:
 c['v3Label']=int(c['text'] in accepted)
 if c['split']=='train':
  values=features[c['offset']:c['offset']+c['windows']]
  if c['label']==1:target=np.ones(len(values),dtype=np.int32)
  elif c['v3Label']==1:
   scores=np.array([old.run(None,{input_name:v.reshape(1,16,96)})[0].flat[0] for v in values]);peak=int(np.argmax(scores));target=np.array([int(abs(i-peak)<=2) for i in range(len(values))])
  else:target=np.zeros(len(values),dtype=np.int32)
  for i,v in enumerate(values):
   if target[i] and hashlib.sha256(v.tobytes()).hexdigest() in silent_hashes:target[i]=0;silence_relabels+=1
  indices.extend(range(c['offset'],c['offset']+c['windows']));labels.extend(target.tolist())
validation=np.load(root/'.venv-wake/wake-data/validation_set_features.npy',mmap_mode='r');split=int(len(validation)*.55)
mining_models=[]
for file in ['mlp-prototype.onnx','broad/mlp-prototype.onnx','multi/mlp-prototype.onnx']:
 graph=onnx.load(root/'.graphify/wake-policy-v2'/file).graph
 weights={t.name:numpy_helper.to_array(t) for t in graph.initializer};mining_models.append(weights)
def mining_predict(batch,weights):
 logit=np.maximum(batch@weights['w1']+weights['b1'],0)@weights['w2']+weights['b2']
 return (1/(1+np.exp(-np.clip(logit,-80,80)))).reshape(-1)
hard=[];sampled=[];mining_started=time.perf_counter()
for start in range(0,split-16,2048):
 stop=min(start+2048,split-16);batch=np.stack([np.asarray(validation[i:i+16]).reshape(-1) for i in range(start,stop)]).astype(np.float32)
 scores=np.max(np.stack([mining_predict(batch,weights) for weights in mining_models]),axis=0)
 hard.extend(batch[scores>=.009]);sampled.extend(batch[np.arange(start,stop)%8==0])
(out/'bank-mining-progress.json').write_text(json.dumps({'phase':'mining-complete','hard':len(hard),'sampled':len(sampled),'silenceRelabels':silence_relabels,'miningMs':(time.perf_counter()-mining_started)*1000}),encoding='utf-8')
background=np.asarray(hard+sampled,dtype=np.float32)
x=np.concatenate([features[indices],background]);y=np.concatenate([np.asarray(labels),np.zeros(len(background))]);rng=np.random.default_rng(2707)

from sklearn.cluster import MiniBatchKMeans
initial={t.name:numpy_helper.to_array(t) for t in onnx.load(out/'finetune-prototype.onnx').graph.initializer}
teacher={t.name:numpy_helper.to_array(t) for t in onnx.load(out/'corrected-prototype.onnx').graph.initializer}
def hidden(batch):return np.maximum(batch@initial['w1']+initial['b1'],0)
def dense(batch,weights=initial):return (1/(1+np.exp(-np.clip(np.maximum(batch@weights['w1']+weights['b1'],0)@weights['w2']+weights['b2'],-80,80)))).reshape(-1)
full=np.fromfile(out/'full-training-negatives.f32',dtype=np.float32).reshape(-1,1536)
negative_raw=np.concatenate([x[y==0],full]);positive_raw=x[y==1]
hx=hidden(x);hfull=hidden(full);hscale=np.std(hx,axis=0);hscale[hscale<.0001]=1
positive=np.unique((hidden(positive_raw)/hscale).astype(np.float32),axis=0)
negative_hidden=np.concatenate([hx[y==0],hfull])/hscale
anchors=np.unique(negative_hidden[dense(negative_raw,teacher)>=.1].astype(np.float32),axis=0)
assert len(anchors)<=2048,'prototype budget exceeded; do not truncate silently'
started=time.perf_counter();kmeans=MiniBatchKMeans(n_clusters=2048,batch_size=4096,max_iter=50,n_init=1,random_state=2707).fit(negative_hidden)
negative=np.concatenate([kmeans.cluster_centers_,anchors]).astype(np.float32)
def predict(batch):
 h=(hidden(batch)/hscale).astype(np.float32)
 # Chunked direct differences avoid cancellation at exact template equality.
 dp=np.full(len(h),np.inf,dtype=np.float32);dn=dp.copy()
 for begin in range(0,len(positive),256):dp=np.minimum(dp,np.sum((h[:,None,:]-positive[None,begin:begin+256,:])**2,axis=2).min(axis=1))
 for begin in range(0,len(negative),256):dn=np.minimum(dn,np.sum((h[:,None,:]-negative[None,begin:begin+256,:])**2,axis=2).min(axis=1))
 return dense(batch)*(dp<dn)
def decisions(scores):
 count=0;ring=[]
 for score in scores:
  ring.append(float(score));ring=ring[-7:]
  if score>=.7 or sum(s>=.6 for s in ring)>=3 or (max(ring)>=.67 and sum(s>=.63 for s in ring)>=2):count+=1;ring=[]
 return count
tests=[]
for c in clips:
 if c['split']=='held-out':
  p=predict(features[c['offset']:c['offset']+c['windows']]);n=decisions(p);tests.append({**c,'candidatePeak':float(np.max(p)),'decisions':n,'status':'PASS' if (n>0)==bool(c['v3Label']) else 'FAIL','scores':p.tolist()})
all_bg=[];n_background=0
for begin in range(split,len(validation)-16,256):
 stop=min(begin+256,len(validation)-16);batch=np.stack([np.asarray(validation[i:i+16]).reshape(-1) for i in range(begin,stop)]).astype(np.float32);p=predict(batch);all_bg.extend(p.tolist());n_background+=len(p)
np.asarray(all_bg,dtype=np.float32).tofile(out/'bank-bg-scores.f32');bg_decisions=decisions(all_bg)
nodes=[helper.make_node('Flatten',['input'],['flat'],axis=1),helper.make_node('MatMul',['flat','w1'],['dot1']),helper.make_node('Add',['dot1','b1'],['hidden']),helper.make_node('Relu',['hidden'],['relu']),helper.make_node('MatMul',['relu','w2'],['dot2']),helper.make_node('Add',['dot2','b2'],['logit']),helper.make_node('Sigmoid',['logit'],['base_score']),helper.make_node('Div',['relu','hscale'],['whitened']),helper.make_node('Unsqueeze',['whitened'],['context'],axes=[1])]
for tag in ['positive','negative']:
 nodes.extend([helper.make_node('Sub',['context',tag],[tag+'_delta']),helper.make_node('Mul',[tag+'_delta',tag+'_delta'],[tag+'_squared']),helper.make_node('ReduceSum',[tag+'_squared'],[tag+'_distance'],axes=[2],keepdims=0),helper.make_node('ReduceMin',[tag+'_distance'],[tag+'_nearest'],axes=[1],keepdims=1)])
nodes.extend([helper.make_node('Less',['positive_nearest','negative_nearest'],['supported']),helper.make_node('Cast',['supported'],['gate'],to=TensorProto.FLOAT),helper.make_node('Mul',['base_score','gate'],['score'])])
constants=[numpy_helper.from_array(initial[n],n) for n in ['w1','b1','w2','b2']]+[numpy_helper.from_array(hscale.astype(np.float32),'hscale'),numpy_helper.from_array(positive[None,:,:],'positive'),numpy_helper.from_array(negative[None,:,:],'negative')]
graph=helper.make_graph(nodes,'ayas-owner-v3-local-prototype-evidence',[helper.make_tensor_value_info('input',TensorProto.FLOAT,[1,16,96])],[helper.make_tensor_value_info('score',TensorProto.FLOAT,[1,1])],constants)
artifact=helper.make_model(graph,opset_imports=[helper.make_opsetid('',11)],producer_name='AYAS bounded local qualification');artifact.ir_version=8;onnx.checker.check_model(artifact);onnx.save(artifact,out/'bank-prototype.onnx')
failures=[t for t in tests if t['status']=='FAIL'];result={'status':'FAIL' if failures or bg_decisions else 'PASS','policy':'owner-v3','trainingOnlyPrototypeCounts':{'positive':len(positive),'negativeCentroids':2048,'exactHardNegativeAnchors':len(anchors)},'heldOutClips':len(tests),'heldOutFailures':failures,'tests':tests,'negativeEmbeddingValidation':{'unseenFrames':n_background,'decisions':bg_decisions,'falseWakeFrames':int(np.sum(np.asarray(all_bg)>=.7)),'maxScore':max(all_bg),'stride':1,'rawAudioReplay':False},'rules':'retain real fine-head score only if nearest positive prototype is closer than nearest negative; ties fail closed; no threshold/vote/cooldown change','fitAndEvaluationMs':(time.perf_counter()-started)*1000,'modelBytes':(out/'bank-prototype.onnx').stat().st_size,'productionInstalled':False,'independentHumanQualification':False,'rawWasmReplay':'SEPARATE_REQUIRED'}
(out/'bank-fit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k not in ['tests','heldOutFailures']}));print('failed ids:',[t['id'] for t in failures]);raise SystemExit(1 if failures or bg_decisions else 0)
