const fs=require('node:fs');let code=fs.readFileSync('.graphify/wake-policy-v3/fit-remaining.py','utf8');
code=code.replace('threadpool_limits(2)','threadpool_limits(4)').replace('import json,pathlib,time','import json,pathlib,time,hashlib');
code=code.replace("indices=[];labels=[]",`silent_features=np.fromfile(out/'silent-features.f32',dtype=np.float32).reshape(-1,1536)
silent_hashes={hashlib.sha256(v.tobytes()).hexdigest() for v in silent_features}
contradictions=json.loads((out/'label-conflicts.json').read_text(encoding='utf-8'))['conflicts']
assert all(c['first']['featureSha256'] in silent_hashes for c in contradictions), 'non-silent label contradiction must be resolved before fitting'
silence_relabels=0
indices=[];labels=[]`);
code=code.replace("  indices.extend(range(c['offset'],c['offset']+c['windows']));labels.extend(target.tolist())",`  for i,v in enumerate(values):
   if target[i] and hashlib.sha256(v.tobytes()).hexdigest() in silent_hashes:target[i]=0;silence_relabels+=1
  indices.extend(range(c['offset'],c['offset']+c['windows']));labels.extend(target.tolist())`);
const a=code.indexOf('mining_sessions='),b=code.indexOf('background=np.asarray',a);if(a<0||b<0)throw Error('mining block missing');
code=code.slice(0,a)+`mining_models=[]
for file in ['mlp-prototype.onnx','broad/mlp-prototype.onnx','multi/mlp-prototype.onnx']:
 graph=onnx.load(root/'.graphify/wake-policy-v2'/file).graph
 weights={t.name:numpy_helper.to_array(t) for t in graph.initializer};mining_models.append(weights)
def mining_predict(batch,weights):
 logit=np.maximum(batch@weights['w1']+weights['b1'],0)@weights['w2']+weights['b2']
 return (1/(1+np.exp(-np.clip(logit,-80,80)))).reshape(-1)
hard=[];sampled=[];mining_started=time.perf_counter()
for start in range(0,split-16,2048):
 stop=min(start+2048,split-16);batch=np.stack([np.asarray(validation[i:i+16]).reshape(-1) for i in range(start,stop)]).astype(np.float32)
 scores=np.max(np.stack([mining_predict(batch,weights) for weights in mining_models]),axis=0)
 hard.extend(batch[scores>=.009]);sampled.extend(batch[np.arange(start,stop)%8==0])
(out/'corrected-progress.json').write_text(json.dumps({'phase':'mining-complete','hard':len(hard),'sampled':len(sampled),'silenceRelabels':silence_relabels,'miningMs':(time.perf_counter()-mining_started)*1000}),encoding='utf-8')
`+code.slice(b);
code=code.replace('hidden_layer_sizes=(128,)','hidden_layer_sizes=(64,)').replace('max_iter=100','max_iter=60').replace("'hidden':128","'hidden':64").replace("'maxIterations':100","'maxIterations':60");
code=code.replace("false_frames=0;max_background=0;n_background=0;bg_decisions=0", "false_frames=0;max_background=0;n_background=0;bg_decisions=0;all_bg_scores=[]");
code=code.replace('bg_decisions+=decisions(p)','all_bg_scores.extend(p.tolist())');
code=code.replace("nodes=[helper.make_node", "bg_decisions=decisions(all_bg_scores)\nnp.asarray(all_bg_scores,dtype=np.float32).tofile(out/'corrected-bg-scores.f32')\nnodes=[helper.make_node");
code=code.replaceAll('remaining-prototype.onnx','corrected-prototype.onnx').replaceAll('remaining-fit.json','corrected-fit.json');
code=code.replace("'productionInstalled':False", "'productionInstalled':False,'silenceRelabels':silence_relabels,'trainingRecipe':'known pure-silence vectors forced negative; vectorized training-only mining; 4-thread64-unit head max60 epochs; no held-out label change'");
fs.writeFileSync('.graphify/wake-policy-v3/fit-remaining-corrected.py',code);console.log('Created corrected private fitter; original pending-fit source/evidence preserved.');
