from threadpoolctl import threadpool_limits
import json,pathlib,time,hashlib,numpy as np,torch,onnx
from onnx import helper,TensorProto,numpy_helper
from torch import nn
threadpool_limits(4);torch.set_num_threads(4);torch.set_num_interop_threads(1);torch.manual_seed(8927)
root=pathlib.Path.cwd();out=root/'.graphify/wake-policy-v3';data=out/'phonetic';clips=json.loads((data/'clips.json').read_text(encoding='utf-8'))['clips'];features=np.memmap(data/'features.f32',mode='r',dtype=np.float32).reshape(-1,3968)
initial={t.name:numpy_helper.to_array(t) for t in onnx.load(out/'finetune-prototype.onnx').graph.initializer}
def hidden(v):return np.maximum(v@initial['w1']+initial['b1'],0).astype(np.float32)
def base(v):return (1/(1+np.exp(-np.clip(hidden(v)@initial['w2']+initial['b2'],-80,80)))).reshape(-1)
indices=[];labels=[]
for c in clips:
 if c['split']=='train-only':
  indices.extend(range(c['offset'],c['offset']+c['windows']));labels.extend([int(c['label']==1 and abs(i-c['peakIndex'])<=2) for i in range(c['windows'])])
raw=np.asarray(features[indices]);y=np.asarray(labels,dtype=np.float32)
silent=np.fromfile(out/'silent-features.f32',dtype=np.float32).reshape(-1,1536);silent_hashes={hashlib.sha256(v.tobytes()).hexdigest() for v in silent};silence_relabels=0
for i in np.flatnonzero(y==1):
 if hashlib.sha256(raw[i,:1536].tobytes()).hexdigest() in silent_hashes:y[i]=0;silence_relabels+=1
h=hidden(raw[:,:1536]);mel=raw[:,1536:].reshape(-1,76,32);mean=mel.reshape(-1,32).mean(axis=0).astype(np.float32);scale=mel.reshape(-1,32).std(axis=0).astype(np.float32);scale[scale<.0001]=1
weights=np.ones(len(y),dtype=np.float32);weights[(y==0)&(base(raw[:,:1536])>=.1)]=5
class Phonetic(nn.Module):
 def __init__(self):
  super().__init__();self.c1=nn.Conv1d(32,16,5,padding=2);self.c2=nn.Conv1d(16,16,3,padding=1);self.d1=nn.Linear(128,32);self.d2=nn.Linear(32,1)
 def forward(self,h,mel):
  v=torch.relu(self.c2(torch.relu(self.c1(mel.transpose(1,2)))));p=torch.cat([h,v.mean(dim=2),v.amax(dim=2),mel[:,-1,:]],dim=1);return self.d2(torch.relu(self.d1(p))).flatten()
net=Phonetic();th=torch.from_numpy(h);tm=torch.from_numpy(((mel-mean)/scale).astype(np.float32));ty=torch.from_numpy(y);tw=torch.from_numpy(weights);positive=np.flatnonzero(y==1);negative=np.flatnonzero(y==0);rng=np.random.default_rng(8927);balanced=np.concatenate([negative,rng.choice(positive,len(negative),replace=True)]);optimizer=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.001);started=time.perf_counter();losses=[]
for epoch in range(10):
 rng.shuffle(balanced);total=0.0
 for begin in range(0,len(balanced),256):
  batch=balanced[begin:begin+256];optimizer.zero_grad();logit=net(th[batch],tm[batch]);loss=(torch.nn.functional.binary_cross_entropy_with_logits(logit,ty[batch],reduction='none')*tw[batch]).mean();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),1);optimizer.step();total+=float(loss.detach())*len(batch)
 losses.append(total/len(balanced));(out/'phonetic-progress.json').write_text(json.dumps({'epoch':epoch+1,'fixedEpochs':10,'trainingLoss':losses[-1],'trainingWindows':len(raw),'balancedWindows':len(balanced)}),encoding='utf-8')
def predict(batch):
 with torch.no_grad():logit=net(torch.from_numpy(hidden(batch[:,:1536])),torch.from_numpy(((batch[:,1536:].reshape(-1,76,32)-mean)/scale).astype(np.float32))).numpy()
 return base(batch[:,:1536])*(logit>0),logit
def decisions(scores):
 count=0;ring=[]
 for score in scores:
  ring.append(float(score));ring=ring[-7:]
  if score>=.7 or sum(s>=.6 for s in ring)>=3 or (max(ring)>=.67 and sum(s>=.63 for s in ring)>=2):count+=1;ring=[]
 return count
tests=[]
for c in clips:
 if c['split']!='train-only':
  p,logit=predict(np.asarray(features[c['offset']:c['offset']+c['windows']]));n=decisions(p);tests.append({**c,'peak':float(np.max(p)),'decisions':n,'status':'PASS' if (n>0)==bool(c['label']) else 'FAIL','scores':p.tolist(),'verifierLogits':logit.tolist()})
constants=[numpy_helper.from_array(initial[n],n) for n in ['w1','b1','w2','b2']]+[numpy_helper.from_array(a,n) for a,n in [(mean,'mean'),(scale,'scale'),(np.asarray(75,dtype=np.int64),'last'),(np.asarray(0,dtype=np.float32),'zero')]]
for tag,layer in [('c1',net.c1),('c2',net.c2),('d1',net.d1),('d2',net.d2)]:
 w=layer.weight.detach().numpy().copy();b=layer.bias.detach().numpy().copy()
 if tag.startswith('d'):w=w.T.copy()
 constants.extend([numpy_helper.from_array(w,tag+'w'),numpy_helper.from_array(b,tag+'b')])
nodes=[helper.make_node('Flatten',['input'],['flat'],axis=1),helper.make_node('MatMul',['flat','w1'],['dot1']),helper.make_node('Add',['dot1','b1'],['hidden']),helper.make_node('Relu',['hidden'],['relu']),helper.make_node('MatMul',['relu','w2'],['dot2']),helper.make_node('Add',['dot2','b2'],['base_logit']),helper.make_node('Sigmoid',['base_logit'],['base_score']),helper.make_node('Sub',['mel_context','mean'],['centered']),helper.make_node('Div',['centered','scale'],['normalized']),helper.make_node('Transpose',['normalized'],['channels'],perm=[0,2,1]),helper.make_node('Conv',['channels','c1w','c1b'],['a1'],kernel_shape=[5],pads=[2,2]),helper.make_node('Relu',['a1'],['r1']),helper.make_node('Conv',['r1','c2w','c2b'],['a2'],kernel_shape=[3],pads=[1,1]),helper.make_node('Relu',['a2'],['r2']),helper.make_node('ReduceMean',['r2'],['average'],axes=[2],keepdims=0),helper.make_node('ReduceMax',['r2'],['maximum'],axes=[2],keepdims=0),helper.make_node('Gather',['normalized','last'],['tail'],axis=1),helper.make_node('Concat',['relu','average','maximum','tail'],['pooled'],axis=1),helper.make_node('MatMul',['pooled','d1w'],['d1dot']),helper.make_node('Add',['d1dot','d1b'],['d1sum']),helper.make_node('Relu',['d1sum'],['d1relu']),helper.make_node('MatMul',['d1relu','d2w'],['d2dot']),helper.make_node('Add',['d2dot','d2b'],['verifier_logit']),helper.make_node('Greater',['verifier_logit','zero'],['positive_evidence']),helper.make_node('Cast',['positive_evidence'],['gate'],to=TensorProto.FLOAT),helper.make_node('Mul',['base_score','gate'],['score'])]
graph=helper.make_graph(nodes,'ayas-owner-v3-private-existing-mel-verifier',[helper.make_tensor_value_info('input',TensorProto.FLOAT,[1,16,96]),helper.make_tensor_value_info('mel_context',TensorProto.FLOAT,[1,76,32])],[helper.make_tensor_value_info('score',TensorProto.FLOAT,[1,1])],constants);artifact=helper.make_model(graph,opset_imports=[helper.make_opsetid('',11)]);artifact.ir_version=8;onnx.checker.check_model(artifact);onnx.save(artifact,out/'phonetic-prototype.onnx')
failures=[t for t in tests if t['status']=='FAIL'];result={'status':'FAIL' if failures else 'PASS','policy':'owner-v3','tests':tests,'failures':failures,'genuineHeldOutClips':sum(c['split']=='held-out' for c in tests),'sourceOverlapAuditClips':sum(c['split']=='source-overlap-audit' for c in tests),'trainingWindows':len(raw),'fixedEpochs':10,'trainingLosses':losses,'modelBytes':(out/'phonetic-prototype.onnx').stat().st_size,'fitAndEvaluationMs':(time.perf_counter()-started)*1000,'verifierRule':'binary positive class logit>0 from fixed balanced classifier; retain fine-head score only with positive evidence; tie/nonpositive fail closed; all original detector thresholds unchanged','negativeEmbeddingOnlyValidation':'NOT_AVAILABLE for composite: auxiliary mel was never recorded; first-stage fine-head1/216590 FAIL remains preserved; no composite background PASS inferred','rawWasmReplay':'SEPARATE_REQUIRED','newCompleteHeldPcm':'SEPARATE_REQUIRED','newUntrainedSpeechChallenge':'SEPARATE_REQUIRED','productionInstalled':False,'independentHuman':False}
(out/'phonetic-fit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k not in ['tests','failures']}));print('failed ids:',[t['id'] for t in failures]);raise SystemExit(1 if failures else 0)
