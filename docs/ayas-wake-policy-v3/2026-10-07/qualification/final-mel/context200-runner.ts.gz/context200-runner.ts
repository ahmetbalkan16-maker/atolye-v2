import assert from 'node:assert/strict';import * as ort from 'onnxruntime-web';import {OpenWakeWordRunner,type WakeRunnerOptions,type WakeSession} from '../../src/components/brain/voice/wake/openWakeWordRunner';
type Models=Pick<WakeRunnerOptions,'melspectrogramUrl'|'embeddingUrl'|'wakewordUrl'>;
export class Context200Runner extends OpenWakeWordRunner{
 private contextState:{frames:number[][];baseline:number[][]|null;full:()=>Float32Array};
 constructor(models:Models){const state:{frames:number[][];baseline:number[][]|null;full:()=>Float32Array}={frames:[],baseline:null,full:()=>new Float32Array(1600)};state.full=()=>{assert.ok(state.frames.length>0);const out=new Float32Array(1600),missing=200-state.frames.length;for(let f=0;f<missing;f++)out.set(state.frames[0],f*8);for(let f=0;f<state.frames.length;f++)out.set(state.frames[f],(missing+f)*8);return out;};
  super({...models,createSession:async(url,options)=>{const s=await ort.InferenceSession.create(url,options);if(url===models.embeddingUrl)return s as WakeSession;if(url===models.wakewordUrl){assert.equal(s.inputNames.length,2);assert.equal(s.inputNames[1],'mel_context');}return{inputNames:s.inputNames,outputNames:s.outputNames,release:()=>s.release(),run:async(feeds)=>{
   if(url===models.wakewordUrl)return s.run({...feeds,mel_context:new ort.Tensor('float32',state.full(),[1,200,8])});
   const result=await s.run(feeds),mel=result[s.outputNames[0]].data as Float32Array;for(let f=0;f<mel.length/32;f++){const bands=[];for(let band=0;band<8;band++){let sum=0;for(let k=0;k<4;k++)sum+=mel[f*32+band*4+k]/10+2;bands.push(sum/4);}state.frames.push(bands);}state.frames=state.frames.slice(-200);return result;
  }};}});this.contextState=state;
 }
 override async warmUp():Promise<void>{await super.warmUp();if(!this.contextState.baseline){const full=this.contextState.full();this.contextState.baseline=Array.from({length:200},(_,f)=>Array.from(full.subarray(f*8,f*8+8)));}}
 override reset():void{super.reset();if(this.contextState?.baseline)this.contextState.frames=this.contextState.baseline.map(f=>f.slice());}
}
