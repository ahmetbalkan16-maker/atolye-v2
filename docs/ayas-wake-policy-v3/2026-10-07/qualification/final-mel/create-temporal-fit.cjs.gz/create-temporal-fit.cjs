const fs=require('fs');let prefix=fs.readFileSync('.graphify/wake-policy-v3/fit-complete.py','utf8');prefix=prefix.slice(0,prefix.indexOf('scaler=StandardScaler().fit(x)')).replaceAll('complete-mining-progress','temporal-mining-progress');
const tail=fs.readFileSync('.graphify/wake-policy-v3/fit-complete.py','utf8');let preparation=tail.slice(tail.indexOf('full_old=np.fromfile'),tail.indexOf('fine_scaled=scaler.transform'));
preparation=preparation.replace('fine_weights=np.ones(len(fine_raw)', 'fine_weights=np.ones(len(fine_raw)');
fs.writeFileSync('.graphify/wake-policy-v3/temporal-prefix.py',prefix+`
import torch
torch.set_num_threads(4);torch.set_num_interop_threads(1);torch.manual_seed(8927)
initial={t.name:numpy_helper.to_array(t) for t in onnx.load(out/'finetune-prototype.onnx').graph.initializer}
def initial_predict(batch):return (1/(1+np.exp(-np.clip(np.maximum(batch@initial['w1']+initial['b1'],0)@initial['w2']+initial['b2'],-80,80)))).reshape(-1)
`+preparation);
