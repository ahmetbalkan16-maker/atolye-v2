const fs=require('node:fs'),assert=require('node:assert/strict');
const read=n=>JSON.parse(fs.readFileSync('.graphify/wake-policy-v3/'+n+'.json'));
const cpu=read('context200-fit'),held=read('context200-held'),sapi=read('context200-sapi');
let clips=0,frames=0,maxError=0,decisionMismatches=0;
for(const c of cpu.tests){const raw=c.split==='held-out'?held.results.find(r=>r.pcmSha256===c.pcmSha256):sapi.results.find(r=>r.text===c.text&&r.variant===c.n);assert.ok(raw);assert.equal(raw.scores.length,c.scores.length);for(let i=0;i<c.scores.length;i++){maxError=Math.max(maxError,Math.abs(c.scores[i]-raw.scores[i]));frames++;}if(c.decisions!==raw.decisions)decisionMismatches++;clips++;}
assert.equal(clips,172);assert.ok(maxError<.00001);assert.equal(decisionMismatches,0);
const r={status:'PASS',scope:'numeric CPU versus actual WASM scores/decisions only; acoustic acceptance remains FAIL',clips,frames,maxAbsoluteError:maxError,decisionMismatches,independentPiperClips:76,sourceOverlapTolgaAuditClips:96};fs.writeFileSync('.graphify/wake-policy-v3/final-mel-parity.json',JSON.stringify(r,null,2)+'\n');console.log(JSON.stringify(r));
