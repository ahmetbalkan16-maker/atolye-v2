import {Context200Runner} from './context200-runner';
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {execFileSync} from 'node:child_process';import {createHash} from 'node:crypto';
import {OpenWakeWordRunner} from '../../src/components/brain/voice/wake/openWakeWordRunner';
import {WakeScoreDetector} from '../../src/components/brain/voice/wakeWordVoiceAdapter';
const root=process.cwd(),fixtures=path.join(root,'.graphify/wake-policy-v2/sapi-fixtures'),manifest=JSON.parse(fs.readFileSync(path.join(fixtures,'manifest.json'),'utf8'));
const model=process.argv[2]?path.resolve(process.argv[2]):path.join(root,'public/wake/ayas.onnx');
const runner=new Context200Runner({melspectrogramUrl:path.join(root,'public/wake/melspectrogram.onnx'),embeddingUrl:path.join(root,'public/wake/embedding_model.onnx'),wakewordUrl:model});
const accepted=new Set(['AYAS','AYAZ','HAYAS','ayas merhaba','ayaz merhaba','hayas merhaba']);
async function main(){const work=fs.mkdtempSync(path.join(os.tmpdir(),'ayas-v3-replay-'));const results=[];try{
 await runner.init();await runner.warmUp();
 for(const row of manifest.rows){const source=path.join(fixtures,row.file),file=path.join(work,'pcm.f32');execFileSync('ffmpeg',['-nostdin','-loglevel','error','-y','-i',source,'-ar','16000','-ac','1','-f','f32le',file],{stdio:'ignore',windowsHide:true});const buffer=fs.readFileSync(file),raw=new Float32Array(buffer.buffer.slice(buffer.byteOffset,buffer.byteOffset+buffer.length)),pcm=new Float32Array(Math.ceil((raw.length+32000)/1280)*1280);pcm.set(raw);
  runner.reset();const detector=new WakeScoreDetector();const scores=[];let decisions=0,firstDecisionMs:null|number=null;
  for(let off=0;off<pcm.length;off+=1280){await runner.accept(pcm.subarray(off,off+1280),score=>{scores.push(score);if(detector.observe(score)){decisions++;firstDecisionMs??=off/16+80;}});}
  const positive=accepted.has(row.text);results.push({...row,positive,split:row.variant<12?'training-source-voice-variation':'held-out-source-voice-variation',sourceSha256:createHash('sha256').update(fs.readFileSync(source)).digest('hex'),decisions,firstDecisionMs,peak:Math.max(...scores),scores,status:(decisions>0)===positive?'PASS':'FAIL'});
 }
 const failures=results.filter(r=>r.status==='FAIL');console.log(JSON.stringify({status:failures.length?'FAIL':'PASS',policy:'owner-v3',model,modelSha256:createHash('sha256').update(fs.readFileSync(model)).digest('hex'),synthetic:true,human:false,source:manifest.source,scenarios:results.length,failures,results,thresholds:'UNCHANGED',phone:'OWNER_ACTION_NOT_RUN'}));if(failures.length)process.exitCode=1;
}finally{runner.dispose();const resolved=path.resolve(work);if(resolved.startsWith(path.resolve(os.tmpdir())+path.sep)&&path.basename(resolved).startsWith('ayas-v3-replay-'))fs.rmSync(resolved,{recursive:true,force:true});}}
main().catch(e=>{console.error(e);process.exitCode=1;});
