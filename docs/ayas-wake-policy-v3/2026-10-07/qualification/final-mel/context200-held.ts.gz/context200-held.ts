import {Context200Runner} from './context200-runner';
import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
import {OpenWakeWordRunner} from '../../src/components/brain/voice/wake/openWakeWordRunner';
import {WakeScoreDetector} from '../../src/components/brain/voice/wakeWordVoiceAdapter';
const root=process.cwd(),out=path.join(root,'.graphify/wake-policy-v3'),source=path.join(root,'.graphify/wake-policy-v2/mel/pcm'),complete=path.join(out,'complete-negative');
const model=path.resolve(process.argv[2]);if(!process.argv[2])throw Error('explicit candidate required');
const runner=new Context200Runner({melspectrogramUrl:path.join(root,'public/wake/melspectrogram.onnx'),embeddingUrl:path.join(root,'public/wake/embedding_model.onnx'),wakewordUrl:model});
const texts=['AYAS','AYAZ','HAYAS','HAYAZ','ayasız','ayaslı','ayazlı','ayasa','hayat','beyaz','yavaş','merhaba','ya','ay','ayas merhaba','ayaz merhaba','hayas merhaba','ayak','ayran','hayır','saat kaç','kapıyı kapat','bugün hava çok güzel','teşekkür ederim'];
const accepted=new Set(['AYAS','AYAZ','HAYAS','ayas merhaba','ayaz merhaba','hayas merhaba']);
const inputs:{text:string;file:string;positive:boolean;source:string;n:number}[]=[];
for(const name of fs.readdirSync(source)){if(!/^\d+\.f32$/.test(name))continue;const id=Number(name.slice(0,-4)),n=id%16,text=texts[Math.floor(id/16)];if(n<12)continue;inputs.push({text,file:path.join(source,name),positive:accepted.has(text),source:'existing held-out stochastic Piper raw PCM; NEVER fitted',n});}
const manifest=JSON.parse(fs.readFileSync(path.join(complete,'clips.json'),'utf8'));for(const c of manifest.clips){if(c.split!=='held-out')continue;const file=path.join(complete,'held-pcm',`${c.id}.f32`);if(!fs.existsSync(file))throw Error('missing held-out PCM');inputs.push({text:c.text,file,positive:false,source:'NEW complete negative held-out raw PCM; NEVER fitted',n:c.n});}
async function main(){const results=[];try{await runner.init();await runner.warmUp();for(const row of inputs){const b=fs.readFileSync(row.file),raw=new Float32Array(b.buffer.slice(b.byteOffset,b.byteOffset+b.length)),pcm=new Float32Array(Math.ceil((raw.length+32000)/1280)*1280);pcm.set(raw);runner.reset();const detector=new WakeScoreDetector();const scores:number[]=[];let decisions=0,firstScoreMs:number|null=null,firstDecisionMs:number|null=null;const start=performance.now();
 for(let off=0;off<pcm.length;off+=1280)await runner.accept(pcm.subarray(off,off+1280),s=>{scores.push(s);firstScoreMs??=off/16+80;if(detector.observe(s)){decisions++;firstDecisionMs??=off/16+80;}});
 if(runner.stats.dropped)throw Error('dropped score frame');results.push({...row,file:path.relative(root,row.file),pcmSha256:createHash('sha256').update(b).digest('hex'),decisions,firstScoreMs,firstDecisionMs,scores,peak:Math.max(...scores),totalMs:performance.now()-start,status:(decisions>0)===row.positive&&firstScoreMs===80?'PASS':'FAIL'});
}const failures=results.filter(r=>r.status==='FAIL');console.log(JSON.stringify({status:failures.length?'FAIL':'PASS',policy:'owner-v3',scenarios:results.length,results,failures,model,modelSha256:createHash('sha256').update(fs.readFileSync(model)).digest('hex'),sourceCount:{existing:inputs.filter(c=>c.positive||c.source.startsWith('existing')).length,new:inputs.filter(c=>c.source.startsWith('NEW')).length},allHeldOutRawClipsPresent:true,thresholds:'UNCHANGED',independentHuman:false,ownerPhone:'NOT_RUN'}));if(failures.length)process.exitCode=1;
}finally{runner.dispose();}}
main().catch(e=>{console.error(e);process.exitCode=1;});
