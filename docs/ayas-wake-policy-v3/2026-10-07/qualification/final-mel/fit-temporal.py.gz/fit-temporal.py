from threadpoolctl import threadpool_limits
import json,pathlib,time,hashlib
import numpy as np
import onnx,onnxruntime as ort
from onnx import helper,TensorProto,numpy_helper
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
threadpool_limits(4)
root=pathlib.Path.cwd();out=root/'.graphify/wake-policy-v3';source=root/'.graphify/wake-policy-v2/multi'
clips=json.loads((source/'prototype-clips.json').read_text(encoding='utf-8'))['clips'];features=np.fromfile(source/'prototype-features.f32',dtype=np.float32).reshape(-1,1536)
options=ort.SessionOptions();options.intra_op_num_threads=2;options.inter_op_num_threads=1
old=ort.InferenceSession(str(root/'public/wake/ayas.onnx'),options,providers=['CPUExecutionProvider']);input_name=old.get_inputs()[0].name
accepted={'AYAS','AYAZ','HAYAS','ayas merhaba','ayaz merhaba','hayas merhaba'}
silent_features=np.fromfile(out/'silent-features.f32',dtype=np.float32).reshape(-1,1536)
silent_hashes={hashlib.sha256(v.tobytes()).hexdigest() for v in silent_features}
contradictions=json.loads((out/'label-conflicts.json').read_text(encoding='utf-8'))['conflicts']
assert all(c['first']['featureSha256'] in silent_hashes for c in contradictions), 'non-silent label contradiction must be resolved before fitting'
silence_relabels=0
indices=[];labels=[]
for c in clips:
 c['v3Label']=int(c['text'] in accepted)
 if c['split']=='train':
  values=features[c['offset']:c['offset']+c['windows']]
  if c['label']==1:target=np.ones(len(values),dtype=np.int32)
  elif c['v3Label']==1:
   scores=np.array([old.run(None,{input_name:v.reshape(1,16,96)})[0].flat[0] for v in values]);peak=int(np.argmax(scores));target=np.array([int(abs(i-peak)<=2) for i in range(len(values))])
  else:target=np.zeros(len(values),dtype=np.int32)
  for i,v in enumerate(values):
   if target[i] and hashlib.sha256(v.tobytes()).hexdigest() in silent_hashes:target[i]=0;silence_relabels+=1
  indices.extend(range(c['offset'],c['offset']+c['windows']));labels.extend(target.tolist())
validation=np.load(root/'.venv-wake/wake-data/validation_set_features.npy',mmap_mode='r');split=int(len(validation)*.55)
mining_models=[]
for file in ['mlp-prototype.onnx','broad/mlp-prototype.onnx','multi/mlp-prototype.onnx']:
 graph=onnx.load(root/'.graphify/wake-policy-v2'/file).graph
 weights={t.name:numpy_helper.to_array(t) for t in graph.initializer};mining_models.append(weights)
def mining_predict(batch,weights):
 logit=np.maximum(batch@weights['w1']+weights['b1'],0)@weights['w2']+weights['b2']
 return (1/(1+np.exp(-np.clip(logit,-80,80)))).reshape(-1)
hard=[];sampled=[];mining_started=time.perf_counter()
for start in range(0,split-16,2048):
 stop=min(start+2048,split-16);batch=np.stack([np.asarray(validation[i:i+16]).reshape(-1) for i in range(start,stop)]).astype(np.float32)
 scores=np.max(np.stack([mining_predict(batch,weights) for weights in mining_models]),axis=0)
 hard.extend(batch[scores>=.009]);sampled.extend(batch[np.arange(start,stop)%8==0])
(out/'temporal-mining-progress.json').write_text(json.dumps({'phase':'mining-complete','hard':len(hard),'sampled':len(sampled),'silenceRelabels':silence_relabels,'miningMs':(time.perf_counter()-mining_started)*1000}),encoding='utf-8')
background=np.asarray(hard+sampled,dtype=np.float32)
x=np.concatenate([features[indices],background]);y=np.concatenate([np.asarray(labels),np.zeros(len(background))]);rng=np.random.default_rng(2707)

import torch
torch.set_num_threads(4);torch.set_num_interop_threads(1);torch.manual_seed(8927)
initial={t.name:numpy_helper.to_array(t) for t in onnx.load(out/'finetune-prototype.onnx').graph.initializer}
def initial_predict(batch):return (1/(1+np.exp(-np.clip(np.maximum(batch@initial['w1']+initial['b1'],0)@initial['w2']+initial['b2'],-80,80)))).reshape(-1)
full_old=np.fromfile(out/'full-training-negatives.f32',dtype=np.float32).reshape(-1,1536)
complete_clips=json.loads((out/'complete-negative/clips.json').read_text(encoding='utf-8'))['clips']
complete_features=np.memmap(out/'complete-negative/features.f32',dtype=np.float32,mode='r').reshape(-1,1536)
train_offsets=[i for c in complete_clips if c['split']=='train-only' for i in range(c['offset'],c['offset']+c['windows'])]
full=np.concatenate([full_old,np.asarray(complete_features[train_offsets])])
new_hard=[]
for start in range(0,split-16,2048):
 stop=min(start+2048,split-16);batch=np.stack([np.asarray(validation[i:i+16]).reshape(-1) for i in range(start,stop)]).astype(np.float32);p=initial_predict(batch);new_hard.extend(batch[p>=.0001])
new_hard=np.asarray(new_hard,dtype=np.float32).reshape(-1,1536)
positive_values=x[y==1];local_negative=x[:len(indices)][y[:len(indices)]==0];easy_background=background[::4]
fine_raw=np.concatenate([positive_values,local_negative,full,new_hard,easy_background]);fine_y=np.concatenate([np.ones(len(positive_values)),np.zeros(len(fine_raw)-len(positive_values))]).astype(np.float32)
fine_weights=np.ones(len(fine_raw),dtype=np.float32);fine_weights[(fine_y==0)&(initial_predict(fine_raw)>=.1)]=5
from torch import nn
mean=fine_raw.reshape(-1,96).mean(axis=0).astype(np.float32);scale=fine_raw.reshape(-1,96).std(axis=0).astype(np.float32);scale[scale<.0001]=1
class Temporal(nn.Module):
 def __init__(self):
  super().__init__();self.c1=nn.Conv1d(96,32,3,padding=1);self.c2=nn.Conv1d(32,32,3,padding=1);self.d1=nn.Linear(160,64);self.d2=nn.Linear(64,1)
 def forward(self,v):
  h=torch.relu(self.c2(torch.relu(self.c1(v.transpose(1,2)))))
  p=torch.cat([h.mean(dim=2),h.amax(dim=2),v[:,-1,:]],dim=1)
  return self.d2(torch.relu(self.d1(p))).flatten()
net=Temporal();tx=torch.from_numpy(((fine_raw.reshape(-1,16,96)-mean)/scale).astype(np.float32));ty=torch.from_numpy(fine_y);tw=torch.from_numpy(fine_weights)
rng=np.random.default_rng(8927);positive=np.flatnonzero(fine_y==1);negative=np.flatnonzero(fine_y==0);indices=np.concatenate([negative,rng.choice(positive,len(negative),replace=True)]);optimizer=torch.optim.AdamW(net.parameters(),lr=.001,weight_decay=.001);started=time.perf_counter();losses=[]
for epoch in range(10):
 rng.shuffle(indices);total=0.0
 for begin in range(0,len(indices),256):
  batch=indices[begin:begin+256];optimizer.zero_grad();logit=net(tx[batch]);loss=(torch.nn.functional.binary_cross_entropy_with_logits(logit,ty[batch],reduction='none')*tw[batch]).mean();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),1);optimizer.step();total+=float(loss.detach())*len(batch)
 losses.append(total/len(indices));(out/'temporal-progress.json').write_text(json.dumps({'epoch':epoch+1,'fixedEpochs':10,'trainingLoss':losses[-1],'trainingWindows':len(fine_raw),'balancedWindows':len(indices)}),encoding='utf-8')
def predict(batch):
 with torch.no_grad():return torch.sigmoid(net(torch.from_numpy(((batch.reshape(-1,16,96)-mean)/scale).astype(np.float32)))).numpy()
def decisions(scores):
 count=0;ring=[]
 for score in scores:
  ring.append(float(score));ring=ring[-7:]
  if score>=.7 or sum(s>=.6 for s in ring)>=3 or (max(ring)>=.67 and sum(s>=.63 for s in ring)>=2):count+=1;ring=[]
 return count
tests=[]
for c in complete_clips:
 if c['split']=='held-out':
  p=predict(np.asarray(complete_features[c['offset']:c['offset']+c['windows']]));n=decisions(p);tests.append({**c,'source':'NEW full-trajectory held-out negative','candidatePeak':float(np.max(p)),'decisions':n,'status':'PASS' if n==0 else 'FAIL','scores':p.tolist()})
for c in clips:
 if c['split']=='held-out':
  p=predict(features[c['offset']:c['offset']+c['windows']]);n=decisions(p);tests.append({**c,'candidatePeak':float(np.max(p)),'decisions':n,'status':'PASS' if (n>0)==bool(c['v3Label']) else 'FAIL','scores':p.tolist()})
all_bg=[]
for begin in range(split,len(validation)-16,1024):
 stop=min(begin+1024,len(validation)-16);batch=np.stack([np.asarray(validation[i:i+16]).reshape(-1) for i in range(begin,stop)]).astype(np.float32);all_bg.extend(predict(batch).tolist())
np.asarray(all_bg,dtype=np.float32).tofile(out/'temporal-bg-scores.f32');bg_decisions=decisions(all_bg)
constants=[numpy_helper.from_array(a,n) for a,n in [(mean,'mean'),(scale,'scale'),(np.asarray(15,dtype=np.int64),'last')]]
for tag,layer in [('c1',net.c1),('c2',net.c2),('d1',net.d1),('d2',net.d2)]:
 weight=layer.weight.detach().numpy().copy();bias=layer.bias.detach().numpy().copy()
 if tag.startswith('d'):weight=weight.T.copy()
 constants.extend([numpy_helper.from_array(weight,tag+'w'),numpy_helper.from_array(bias,tag+'b')])
nodes=[helper.make_node('Sub',['input','mean'],['centered']),helper.make_node('Div',['centered','scale'],['normalized']),helper.make_node('Transpose',['normalized'],['channels'],perm=[0,2,1]),helper.make_node('Conv',['channels','c1w','c1b'],['a1'],kernel_shape=[3],pads=[1,1]),helper.make_node('Relu',['a1'],['r1']),helper.make_node('Conv',['r1','c2w','c2b'],['a2'],kernel_shape=[3],pads=[1,1]),helper.make_node('Relu',['a2'],['r2']),helper.make_node('ReduceMean',['r2'],['average'],axes=[2],keepdims=0),helper.make_node('ReduceMax',['r2'],['maximum'],axes=[2],keepdims=0),helper.make_node('Gather',['normalized','last'],['tail'],axis=1),helper.make_node('Concat',['average','maximum','tail'],['pooled'],axis=1),helper.make_node('MatMul',['pooled','d1w'],['d1dot']),helper.make_node('Add',['d1dot','d1b'],['d1sum']),helper.make_node('Relu',['d1sum'],['d1relu']),helper.make_node('MatMul',['d1relu','d2w'],['d2dot']),helper.make_node('Add',['d2dot','d2b'],['logit']),helper.make_node('Sigmoid',['logit'],['score'])]
graph=helper.make_graph(nodes,'ayas-owner-v3-private-temporal-candidate',[helper.make_tensor_value_info('input',TensorProto.FLOAT,[1,16,96])],[helper.make_tensor_value_info('score',TensorProto.FLOAT,[1,1])],constants);artifact=helper.make_model(graph,opset_imports=[helper.make_opsetid('',11)]);artifact.ir_version=8;onnx.checker.check_model(artifact);onnx.save(artifact,out/'temporal-prototype.onnx')
failures=[t for t in tests if t['status']=='FAIL'];result={'status':'FAIL' if failures or bg_decisions else 'PASS','policy':'owner-v3','purpose':'remaining true false positives, all three wake names positive; no HAYAS discriminator','heldOutClips':len(tests),'heldOutFailures':failures,'tests':tests,'negativeEmbeddingValidation':{'unseenFrames':len(all_bg),'decisions':bg_decisions,'falseWakeFrames':int(np.sum(np.asarray(all_bg)>=.7)),'maxScore':max(all_bg),'stride':1,'rawAudioReplay':False},'fixedEpochs':10,'modelBytes':(out/'temporal-prototype.onnx').stat().st_size,'productionInstalled':False,'trainingRecipe':'same fixed train-only corpus, channel normalization shared across time, two32-channel temporal convolutions plus mean/max/tail pooling; fixed10 epochs AdamW lr0.001 weightDecay0.001; no held-out data fitting; original detector rules','trainingWindows':len(fine_raw),'trainingLosses':losses,'fitAndEvaluationMs':(time.perf_counter()-started)*1000,'independentHumanQualification':False,'rawWasmReplay':'SEPARATE_REQUIRED'}
(out/'temporal-fit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k not in ['tests','heldOutFailures']}));print('failed ids:',[t['id'] for t in failures]);raise SystemExit(1 if failures or bg_decisions else 0)

