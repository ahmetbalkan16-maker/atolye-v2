import assert from 'node:assert/strict';import * as ort from 'onnxruntime-web';import type {WakeRunnerOptions,WakeSession} from '../../src/components/brain/voice/wake/openWakeWordRunner';
export function withPhoneticSessions(models:Pick<WakeRunnerOptions,'melspectrogramUrl'|'embeddingUrl'|'wakewordUrl'>):WakeRunnerOptions{
 let latestMel=new Float32Array(76*32);
 return{...models,createSession:async(url,options)=>{const s=await ort.InferenceSession.create(url,options);if(url===models.melspectrogramUrl)return s as WakeSession;
  if(url===models.wakewordUrl){assert.equal(s.inputNames.length,2);assert.equal(s.inputNames[1],'mel_context');}
  return{inputNames:s.inputNames,outputNames:s.outputNames,release:()=>s.release(),run:async(feeds)=>{if(url===models.embeddingUrl){assert.equal(feeds[s.inputNames[0]].data.length,76*32);latestMel=new Float32Array(feeds[s.inputNames[0]].data as Float32Array);return s.run(feeds);}return s.run({...feeds,mel_context:new ort.Tensor('float32',latestMel,[1,76,32])});}};
 }};
}
