from threadpoolctl import threadpool_limits
import json,pathlib,time
import numpy as np
import onnx,onnxruntime as ort
from onnx import helper,TensorProto,numpy_helper
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
threadpool_limits(2)
root=pathlib.Path.cwd();out=root/'.graphify/wake-policy-v3';source=root/'.graphify/wake-policy-v2/multi'
clips=json.loads((source/'prototype-clips.json').read_text(encoding='utf-8'))['clips'];features=np.fromfile(source/'prototype-features.f32',dtype=np.float32).reshape(-1,1536)
options=ort.SessionOptions();options.intra_op_num_threads=2;options.inter_op_num_threads=1
old=ort.InferenceSession(str(root/'public/wake/ayas.onnx'),options,providers=['CPUExecutionProvider']);input_name=old.get_inputs()[0].name
accepted={'AYAS','AYAZ','HAYAS','ayas merhaba','ayaz merhaba','hayas merhaba'}
indices=[];labels=[]
for c in clips:
 c['v3Label']=int(c['text'] in accepted)
 if c['split']=='train':
  values=features[c['offset']:c['offset']+c['windows']]
  if c['label']==1:target=np.ones(len(values),dtype=np.int32)
  elif c['v3Label']==1:
   scores=np.array([old.run(None,{input_name:v.reshape(1,16,96)})[0].flat[0] for v in values]);peak=int(np.argmax(scores));target=np.array([int(abs(i-peak)<=2) for i in range(len(values))])
  else:target=np.zeros(len(values),dtype=np.int32)
  indices.extend(range(c['offset'],c['offset']+c['windows']));labels.extend(target.tolist())
validation=np.load(root/'.venv-wake/wake-data/validation_set_features.npy',mmap_mode='r');split=int(len(validation)*.55)
mining_sessions=[ort.InferenceSession(str(root/'.graphify/wake-policy-v2'/f),options,providers=['CPUExecutionProvider']) for f in ['mlp-prototype.onnx','broad/mlp-prototype.onnx','multi/mlp-prototype.onnx']]
hard=[];sampled=[]
for start in range(0,split-16,512):
 stop=min(start+512,split-16);batch=np.stack([np.asarray(validation[i:i+16]).reshape(-1) for i in range(start,stop)]).astype(np.float32)
 # Mine only the training prefix. Held-out backgrounds never influence fitting.
 scores=np.max(np.stack([np.array([s.run(None,{s.get_inputs()[0].name:v.reshape(1,16,96)})[0].flat[0] for v in batch]) for s in mining_sessions]),axis=0)
 hard.extend(batch[scores>=.01]);sampled.extend(batch[np.arange(start,stop)%8==0])
background=np.asarray(hard+sampled,dtype=np.float32)
x=np.concatenate([features[indices],background]);y=np.concatenate([np.asarray(labels),np.zeros(len(background))]);rng=np.random.default_rng(2707)
scaler=StandardScaler().fit(x);scaled=scaler.transform(x);positive=np.flatnonzero(y==1);negative=np.flatnonzero(y==0)
balanced=np.concatenate([negative,rng.choice(positive,len(negative),replace=True)]);rng.shuffle(balanced)
started=time.perf_counter();model=MLPClassifier(hidden_layer_sizes=(128,),alpha=.1,batch_size=256,learning_rate_init=.001,max_iter=100,random_state=2707,n_iter_no_change=12).fit(scaled[balanced],y[balanced])
w1=(model.coefs_[0]/scaler.scale_[:,None]).astype(np.float32);b1=(model.intercepts_[0]-(scaler.mean_/scaler.scale_)@model.coefs_[0]).astype(np.float32);w2=model.coefs_[1].astype(np.float32);b2=model.intercepts_[1].astype(np.float32)
def predict(x):return (1/(1+np.exp(-np.clip(np.maximum(x@w1+b1,0)@w2+b2,-80,80)))).reshape(-1)
def decisions(scores):
 count=0;ring=[]
 for score in scores:
  ring.append(float(score));ring=ring[-7:]
  if score>=.7 or sum(s>=.6 for s in ring)>=3 or (max(ring)>=.67 and sum(s>=.63 for s in ring)>=2):count+=1;ring=[]
 return count
tests=[]
for c in clips:
 if c['split']=='held-out':
  p=predict(features[c['offset']:c['offset']+c['windows']]);n=decisions(p)
  tests.append({**c,'candidatePeak':float(np.max(p)),'decisions':n,'status':'PASS' if (n>0)==bool(c['v3Label']) else 'FAIL','scores':p.tolist()})
false_frames=0;max_background=0;n_background=0;bg_decisions=0
for start in range(split,len(validation)-16,2048):
 stop=min(start+2048,len(validation)-16);batch=np.stack([np.asarray(validation[i:i+16]).reshape(-1) for i in range(start,stop)]).astype(np.float32);p=predict(batch);false_frames+=int(np.sum(p>=.7));max_background=max(max_background,float(np.max(p)));n_background+=len(p);bg_decisions+=decisions(p)
nodes=[helper.make_node('Flatten',['input'],['flat'],axis=1),helper.make_node('MatMul',['flat','w1'],['dot1']),helper.make_node('Add',['dot1','b1'],['hidden']),helper.make_node('Relu',['hidden'],['relu']),helper.make_node('MatMul',['relu','w2'],['dot2']),helper.make_node('Add',['dot2','b2'],['logit']),helper.make_node('Sigmoid',['logit'],['score'])]
graph=helper.make_graph(nodes,'ayas-owner-v3-private-remaining-gate-candidate',[helper.make_tensor_value_info('input',TensorProto.FLOAT,[1,16,96])],[helper.make_tensor_value_info('score',TensorProto.FLOAT,[1,1])],[numpy_helper.from_array(a,n) for a,n in [(w1,'w1'),(b1,'b1'),(w2,'w2'),(b2,'b2')]])
artifact=helper.make_model(graph,opset_imports=[helper.make_opsetid('',13)],producer_name='AYAS bounded private qualification');artifact.ir_version=8;onnx.checker.check_model(artifact);onnx.save(artifact,out/'remaining-prototype.onnx')
failures=[t for t in tests if t['status']=='FAIL'];result={'status':'FAIL' if failures or bg_decisions else 'PASS','policy':'owner-v3','purpose':'remaining suffix/ordinary false positives and AYAZ reliability; NOT HAYAS discrimination','trainingClips':sum(c['split']=='train' for c in clips),'heldOutClips':len(tests),'trainingWindows':len(x),'hardMinedTrainingOnly':len(hard),'heldOutFailures':failures,'tests':tests,'negativeEmbeddingValidation':{'source':'existing precomputed negative features','unseenFrames':n_background,'falseWakeFrames':false_frames,'decisions':bg_decisions,'maxScore':max_background,'stride':1,'rawAudioReplay':False},'fitAndEvaluationMs':(time.perf_counter()-started)*1000,'iterations':model.n_iter_,'hyperparameters':{'hidden':128,'alpha':.1,'hard':.7,'soft':.6,'softVotes':'3/7','near':.67,'nearVotes':'.63 x2','maxIterations':100},'modelBytes':(out/'remaining-prototype.onnx').stat().st_size,'productionInstalled':False,'rawWasmReplay':'SEPARATE_REQUIRED','independentHumanQualification':False}
(out/'remaining-fit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if k not in ['tests','heldOutFailures']}));print('failed clip ids:',[t['id'] for t in failures]);raise SystemExit(1 if failures or bg_decisions else 0)
